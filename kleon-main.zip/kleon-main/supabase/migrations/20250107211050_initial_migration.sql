create schema if not exists "payload";

create type "payload"."enum__posts_v_version_status" as enum ('draft', 'published');

create type "payload"."enum_forms_confirmation_type" as enum ('message', 'redirect');

create type "payload"."enum_posts_status" as enum ('draft', 'published');

create type "payload"."enum_redirects_to_type" as enum ('reference', 'custom');

create sequence "payload"."_posts_v_id_seq";

create sequence "payload"."_posts_v_rels_id_seq";

create sequence "payload"."_posts_v_version_populated_authors_id_seq";

create sequence "payload"."categories_id_seq";

create sequence "payload"."form_submissions_id_seq";

create sequence "payload"."forms_id_seq";

create sequence "payload"."media_id_seq";

create sequence "payload"."payload_locked_documents_id_seq";

create sequence "payload"."payload_locked_documents_rels_id_seq";

create sequence "payload"."payload_migrations_id_seq";

create sequence "payload"."payload_preferences_id_seq";

create sequence "payload"."payload_preferences_rels_id_seq";

create sequence "payload"."posts_id_seq";

create sequence "payload"."posts_rels_id_seq";

create sequence "payload"."redirects_id_seq";

create sequence "payload"."redirects_rels_id_seq";

create sequence "payload"."search_id_seq";

create sequence "payload"."search_rels_id_seq";

create sequence "payload"."users_id_seq";

create table "payload"."_posts_v" (
    "id" integer not null default nextval('payload._posts_v_id_seq'::regclass),
    "parent_id" integer,
    "version_slug" character varying,
    "version_title" character varying,
    "version_content" jsonb,
    "version_updated_at" timestamp(3) with time zone,
    "version_created_at" timestamp(3) with time zone,
    "version__status" payload.enum__posts_v_version_status default 'draft'::payload.enum__posts_v_version_status,
    "created_at" timestamp(3) with time zone not null default now(),
    "updated_at" timestamp(3) with time zone not null default now(),
    "latest" boolean,
    "autosave" boolean,
    "version_hero_image_id" integer,
    "version_meta_title" character varying,
    "version_meta_image_id" integer,
    "version_meta_description" character varying,
    "version_published_at" timestamp(3) with time zone,
    "version_slug_lock" boolean default true
);


create table "payload"."_posts_v_rels" (
    "id" integer not null default nextval('payload._posts_v_rels_id_seq'::regclass),
    "order" integer,
    "parent_id" integer not null,
    "path" character varying not null,
    "posts_id" integer,
    "categories_id" integer,
    "users_id" integer
);


create table "payload"."_posts_v_version_populated_authors" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "id" integer not null default nextval('payload._posts_v_version_populated_authors_id_seq'::regclass),
    "_uuid" character varying,
    "name" character varying
);


create table "payload"."categories" (
    "id" integer not null default nextval('payload.categories_id_seq'::regclass),
    "title" character varying not null,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now(),
    "parent_id" integer
);


create table "payload"."categories_breadcrumbs" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "id" character varying not null,
    "doc_id" integer,
    "url" character varying,
    "label" character varying
);


create table "payload"."form_submissions" (
    "id" integer not null default nextval('payload.form_submissions_id_seq'::regclass),
    "form_id" integer not null,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."form_submissions_submission_data" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "id" character varying not null,
    "field" character varying not null,
    "value" character varying not null
);


create table "payload"."forms" (
    "id" integer not null default nextval('payload.forms_id_seq'::regclass),
    "title" character varying not null,
    "submit_button_label" character varying,
    "confirmation_type" payload.enum_forms_confirmation_type default 'message'::payload.enum_forms_confirmation_type,
    "confirmation_message" jsonb,
    "redirect_url" character varying,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."forms_blocks_checkbox" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "required" boolean,
    "default_value" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_country" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_email" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_message" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "message" jsonb,
    "block_name" character varying
);


create table "payload"."forms_blocks_number" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "default_value" numeric,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_select" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "default_value" character varying,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_select_options" (
    "_order" integer not null,
    "_parent_id" character varying not null,
    "id" character varying not null,
    "label" character varying not null,
    "value" character varying not null
);


create table "payload"."forms_blocks_state" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_text" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "default_value" character varying,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_blocks_textarea" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "_path" text not null,
    "id" character varying not null,
    "name" character varying not null,
    "label" character varying,
    "width" numeric,
    "default_value" character varying,
    "required" boolean,
    "block_name" character varying
);


create table "payload"."forms_emails" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "id" character varying not null,
    "email_to" character varying,
    "cc" character varying,
    "bcc" character varying,
    "reply_to" character varying,
    "email_from" character varying,
    "subject" character varying not null default 'You''''ve received a new message.'::character varying,
    "message" jsonb
);


create table "payload"."media" (
    "id" integer not null default nextval('payload.media_id_seq'::regclass),
    "alt" character varying,
    "caption" jsonb,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now(),
    "url" character varying,
    "thumbnail_u_r_l" character varying,
    "filename" character varying,
    "mime_type" character varying,
    "filesize" numeric,
    "width" numeric,
    "height" numeric,
    "focal_x" numeric,
    "focal_y" numeric,
    "prefix" character varying default 'media'::character varying
);


create table "payload"."payload_locked_documents" (
    "id" integer not null default nextval('payload.payload_locked_documents_id_seq'::regclass),
    "global_slug" character varying,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."payload_locked_documents_rels" (
    "id" integer not null default nextval('payload.payload_locked_documents_rels_id_seq'::regclass),
    "order" integer,
    "parent_id" integer not null,
    "path" character varying not null,
    "users_id" integer,
    "posts_id" integer,
    "categories_id" integer,
    "media_id" integer,
    "redirects_id" integer,
    "search_id" integer,
    "forms_id" integer,
    "form_submissions_id" integer
);


create table "payload"."payload_migrations" (
    "id" integer not null default nextval('payload.payload_migrations_id_seq'::regclass),
    "name" character varying,
    "batch" numeric,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."payload_preferences" (
    "id" integer not null default nextval('payload.payload_preferences_id_seq'::regclass),
    "key" character varying,
    "value" jsonb,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."payload_preferences_rels" (
    "id" integer not null default nextval('payload.payload_preferences_rels_id_seq'::regclass),
    "order" integer,
    "parent_id" integer not null,
    "path" character varying not null,
    "users_id" integer
);


create table "payload"."posts" (
    "id" integer not null default nextval('payload.posts_id_seq'::regclass),
    "slug" character varying,
    "title" character varying,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now(),
    "content" jsonb,
    "_status" payload.enum_posts_status default 'draft'::payload.enum_posts_status,
    "hero_image_id" integer,
    "meta_title" character varying,
    "meta_image_id" integer,
    "meta_description" character varying,
    "published_at" timestamp(3) with time zone,
    "slug_lock" boolean default true
);


create table "payload"."posts_populated_authors" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "id" character varying not null,
    "name" character varying
);


create table "payload"."posts_rels" (
    "id" integer not null default nextval('payload.posts_rels_id_seq'::regclass),
    "order" integer,
    "parent_id" integer not null,
    "path" character varying not null,
    "posts_id" integer,
    "categories_id" integer,
    "users_id" integer
);


create table "payload"."redirects" (
    "id" integer not null default nextval('payload.redirects_id_seq'::regclass),
    "from" character varying not null,
    "to_type" payload.enum_redirects_to_type default 'reference'::payload.enum_redirects_to_type,
    "to_url" character varying,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."redirects_rels" (
    "id" integer not null default nextval('payload.redirects_rels_id_seq'::regclass),
    "order" integer,
    "parent_id" integer not null,
    "path" character varying not null,
    "posts_id" integer
);


create table "payload"."search" (
    "id" integer not null default nextval('payload.search_id_seq'::regclass),
    "title" character varying,
    "priority" numeric,
    "slug" character varying,
    "meta_title" character varying,
    "meta_description" character varying,
    "meta_image_id" integer,
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now()
);


create table "payload"."search_categories" (
    "_order" integer not null,
    "_parent_id" integer not null,
    "id" character varying not null,
    "relation_to" character varying,
    "title" character varying
);


create table "payload"."search_rels" (
    "id" integer not null default nextval('payload.search_rels_id_seq'::regclass),
    "order" integer,
    "parent_id" integer not null,
    "path" character varying not null,
    "posts_id" integer
);


create table "payload"."users" (
    "id" integer not null default nextval('payload.users_id_seq'::regclass),
    "updated_at" timestamp(3) with time zone not null default now(),
    "created_at" timestamp(3) with time zone not null default now(),
    "email" character varying not null,
    "reset_password_token" character varying,
    "reset_password_expiration" timestamp(3) with time zone,
    "salt" character varying,
    "hash" character varying,
    "login_attempts" numeric default 0,
    "lock_until" timestamp(3) with time zone,
    "name" character varying
);


alter sequence "payload"."_posts_v_id_seq" owned by "payload"."_posts_v"."id";

alter sequence "payload"."_posts_v_rels_id_seq" owned by "payload"."_posts_v_rels"."id";

alter sequence "payload"."_posts_v_version_populated_authors_id_seq" owned by "payload"."_posts_v_version_populated_authors"."id";

alter sequence "payload"."categories_id_seq" owned by "payload"."categories"."id";

alter sequence "payload"."form_submissions_id_seq" owned by "payload"."form_submissions"."id";

alter sequence "payload"."forms_id_seq" owned by "payload"."forms"."id";

alter sequence "payload"."media_id_seq" owned by "payload"."media"."id";

alter sequence "payload"."payload_locked_documents_id_seq" owned by "payload"."payload_locked_documents"."id";

alter sequence "payload"."payload_locked_documents_rels_id_seq" owned by "payload"."payload_locked_documents_rels"."id";

alter sequence "payload"."payload_migrations_id_seq" owned by "payload"."payload_migrations"."id";

alter sequence "payload"."payload_preferences_id_seq" owned by "payload"."payload_preferences"."id";

alter sequence "payload"."payload_preferences_rels_id_seq" owned by "payload"."payload_preferences_rels"."id";

alter sequence "payload"."posts_id_seq" owned by "payload"."posts"."id";

alter sequence "payload"."posts_rels_id_seq" owned by "payload"."posts_rels"."id";

alter sequence "payload"."redirects_id_seq" owned by "payload"."redirects"."id";

alter sequence "payload"."redirects_rels_id_seq" owned by "payload"."redirects_rels"."id";

alter sequence "payload"."search_id_seq" owned by "payload"."search"."id";

alter sequence "payload"."search_rels_id_seq" owned by "payload"."search_rels"."id";

alter sequence "payload"."users_id_seq" owned by "payload"."users"."id";

CREATE INDEX _posts_v_autosave_10_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_11_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_12_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_1_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_2_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_3_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_4_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_5_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_6_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_7_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_8_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_9_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_autosave_idx ON payload._posts_v USING btree (autosave);

CREATE INDEX _posts_v_created_at_10_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_11_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_12_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_1_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_2_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_3_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_4_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_5_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_6_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_7_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_8_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_9_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_created_at_idx ON payload._posts_v USING btree (created_at);

CREATE INDEX _posts_v_latest_10_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_11_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_12_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_1_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_2_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_3_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_4_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_5_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_6_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_7_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_8_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_9_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_latest_idx ON payload._posts_v USING btree (latest);

CREATE INDEX _posts_v_parent_10_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_11_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_12_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_1_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_2_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_3_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_4_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_5_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_6_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_7_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_8_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_9_idx ON payload._posts_v USING btree (parent_id);

CREATE INDEX _posts_v_parent_idx ON payload._posts_v USING btree (parent_id);

CREATE UNIQUE INDEX _posts_v_pkey ON payload._posts_v USING btree (id);

CREATE INDEX _posts_v_rels_categories_id_idx ON payload._posts_v_rels USING btree (categories_id);

CREATE INDEX _posts_v_rels_order_idx ON payload._posts_v_rels USING btree ("order");

CREATE INDEX _posts_v_rels_parent_idx ON payload._posts_v_rels USING btree (parent_id);

CREATE INDEX _posts_v_rels_path_idx ON payload._posts_v_rels USING btree (path);

CREATE UNIQUE INDEX _posts_v_rels_pkey ON payload._posts_v_rels USING btree (id);

CREATE INDEX _posts_v_rels_posts_id_idx ON payload._posts_v_rels USING btree (posts_id);

CREATE INDEX _posts_v_rels_users_id_idx ON payload._posts_v_rels USING btree (users_id);

CREATE INDEX _posts_v_updated_at_10_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_11_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_12_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_1_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_2_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_3_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_4_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_5_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_6_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_7_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_8_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_9_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_updated_at_idx ON payload._posts_v USING btree (updated_at);

CREATE INDEX _posts_v_version_meta_version_meta_image_idx ON payload._posts_v USING btree (version_meta_image_id);

CREATE INDEX _posts_v_version_populated_authors_order_idx ON payload._posts_v_version_populated_authors USING btree (_order);

CREATE INDEX _posts_v_version_populated_authors_parent_id_idx ON payload._posts_v_version_populated_authors USING btree (_parent_id);

CREATE UNIQUE INDEX _posts_v_version_populated_authors_pkey ON payload._posts_v_version_populated_authors USING btree (id);

CREATE INDEX _posts_v_version_version__status_10_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_11_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_12_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_1_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_2_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_3_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_4_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_5_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_6_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_7_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_8_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_9_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version__status_idx ON payload._posts_v USING btree (version__status);

CREATE INDEX _posts_v_version_version_created_at_10_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_11_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_12_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_1_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_2_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_3_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_4_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_5_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_6_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_7_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_8_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_9_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_created_at_idx ON payload._posts_v USING btree (version_created_at);

CREATE INDEX _posts_v_version_version_hero_image_idx ON payload._posts_v USING btree (version_hero_image_id);

CREATE INDEX _posts_v_version_version_slug_10_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_11_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_12_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_1_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_2_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_3_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_4_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_5_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_6_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_7_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_8_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_9_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_slug_idx ON payload._posts_v USING btree (version_slug);

CREATE INDEX _posts_v_version_version_updated_at_10_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_11_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_12_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_1_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_2_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_3_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_4_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_5_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_6_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_7_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_8_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_9_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX _posts_v_version_version_updated_at_idx ON payload._posts_v USING btree (version_updated_at);

CREATE INDEX categories_breadcrumbs_doc_idx ON payload.categories_breadcrumbs USING btree (doc_id);

CREATE INDEX categories_breadcrumbs_order_idx ON payload.categories_breadcrumbs USING btree (_order);

CREATE INDEX categories_breadcrumbs_parent_id_idx ON payload.categories_breadcrumbs USING btree (_parent_id);

CREATE UNIQUE INDEX categories_breadcrumbs_pkey ON payload.categories_breadcrumbs USING btree (id);

CREATE INDEX categories_created_at_idx ON payload.categories USING btree (created_at);

CREATE INDEX categories_parent_idx ON payload.categories USING btree (parent_id);

CREATE UNIQUE INDEX categories_pkey ON payload.categories USING btree (id);

CREATE INDEX categories_updated_at_idx ON payload.categories USING btree (updated_at);

CREATE INDEX form_submissions_created_at_idx ON payload.form_submissions USING btree (created_at);

CREATE INDEX form_submissions_form_idx ON payload.form_submissions USING btree (form_id);

CREATE UNIQUE INDEX form_submissions_pkey ON payload.form_submissions USING btree (id);

CREATE INDEX form_submissions_submission_data_order_idx ON payload.form_submissions_submission_data USING btree (_order);

CREATE INDEX form_submissions_submission_data_parent_id_idx ON payload.form_submissions_submission_data USING btree (_parent_id);

CREATE UNIQUE INDEX form_submissions_submission_data_pkey ON payload.form_submissions_submission_data USING btree (id);

CREATE INDEX form_submissions_updated_at_idx ON payload.form_submissions USING btree (updated_at);

CREATE INDEX forms_blocks_checkbox_order_idx ON payload.forms_blocks_checkbox USING btree (_order);

CREATE INDEX forms_blocks_checkbox_parent_id_idx ON payload.forms_blocks_checkbox USING btree (_parent_id);

CREATE INDEX forms_blocks_checkbox_path_idx ON payload.forms_blocks_checkbox USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_checkbox_pkey ON payload.forms_blocks_checkbox USING btree (id);

CREATE INDEX forms_blocks_country_order_idx ON payload.forms_blocks_country USING btree (_order);

CREATE INDEX forms_blocks_country_parent_id_idx ON payload.forms_blocks_country USING btree (_parent_id);

CREATE INDEX forms_blocks_country_path_idx ON payload.forms_blocks_country USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_country_pkey ON payload.forms_blocks_country USING btree (id);

CREATE INDEX forms_blocks_email_order_idx ON payload.forms_blocks_email USING btree (_order);

CREATE INDEX forms_blocks_email_parent_id_idx ON payload.forms_blocks_email USING btree (_parent_id);

CREATE INDEX forms_blocks_email_path_idx ON payload.forms_blocks_email USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_email_pkey ON payload.forms_blocks_email USING btree (id);

CREATE INDEX forms_blocks_message_order_idx ON payload.forms_blocks_message USING btree (_order);

CREATE INDEX forms_blocks_message_parent_id_idx ON payload.forms_blocks_message USING btree (_parent_id);

CREATE INDEX forms_blocks_message_path_idx ON payload.forms_blocks_message USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_message_pkey ON payload.forms_blocks_message USING btree (id);

CREATE INDEX forms_blocks_number_order_idx ON payload.forms_blocks_number USING btree (_order);

CREATE INDEX forms_blocks_number_parent_id_idx ON payload.forms_blocks_number USING btree (_parent_id);

CREATE INDEX forms_blocks_number_path_idx ON payload.forms_blocks_number USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_number_pkey ON payload.forms_blocks_number USING btree (id);

CREATE INDEX forms_blocks_select_options_order_idx ON payload.forms_blocks_select_options USING btree (_order);

CREATE INDEX forms_blocks_select_options_parent_id_idx ON payload.forms_blocks_select_options USING btree (_parent_id);

CREATE UNIQUE INDEX forms_blocks_select_options_pkey ON payload.forms_blocks_select_options USING btree (id);

CREATE INDEX forms_blocks_select_order_idx ON payload.forms_blocks_select USING btree (_order);

CREATE INDEX forms_blocks_select_parent_id_idx ON payload.forms_blocks_select USING btree (_parent_id);

CREATE INDEX forms_blocks_select_path_idx ON payload.forms_blocks_select USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_select_pkey ON payload.forms_blocks_select USING btree (id);

CREATE INDEX forms_blocks_state_order_idx ON payload.forms_blocks_state USING btree (_order);

CREATE INDEX forms_blocks_state_parent_id_idx ON payload.forms_blocks_state USING btree (_parent_id);

CREATE INDEX forms_blocks_state_path_idx ON payload.forms_blocks_state USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_state_pkey ON payload.forms_blocks_state USING btree (id);

CREATE INDEX forms_blocks_text_order_idx ON payload.forms_blocks_text USING btree (_order);

CREATE INDEX forms_blocks_text_parent_id_idx ON payload.forms_blocks_text USING btree (_parent_id);

CREATE INDEX forms_blocks_text_path_idx ON payload.forms_blocks_text USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_text_pkey ON payload.forms_blocks_text USING btree (id);

CREATE INDEX forms_blocks_textarea_order_idx ON payload.forms_blocks_textarea USING btree (_order);

CREATE INDEX forms_blocks_textarea_parent_id_idx ON payload.forms_blocks_textarea USING btree (_parent_id);

CREATE INDEX forms_blocks_textarea_path_idx ON payload.forms_blocks_textarea USING btree (_path);

CREATE UNIQUE INDEX forms_blocks_textarea_pkey ON payload.forms_blocks_textarea USING btree (id);

CREATE INDEX forms_created_at_idx ON payload.forms USING btree (created_at);

CREATE INDEX forms_emails_order_idx ON payload.forms_emails USING btree (_order);

CREATE INDEX forms_emails_parent_id_idx ON payload.forms_emails USING btree (_parent_id);

CREATE UNIQUE INDEX forms_emails_pkey ON payload.forms_emails USING btree (id);

CREATE UNIQUE INDEX forms_pkey ON payload.forms USING btree (id);

CREATE INDEX forms_updated_at_idx ON payload.forms USING btree (updated_at);

CREATE INDEX media_created_at_idx ON payload.media USING btree (created_at);

CREATE UNIQUE INDEX media_filename_idx ON payload.media USING btree (filename);

CREATE UNIQUE INDEX media_pkey ON payload.media USING btree (id);

CREATE INDEX media_updated_at_idx ON payload.media USING btree (updated_at);

CREATE INDEX payload_locked_documents_created_at_10_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_11_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_12_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_13_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_14_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_15_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_16_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_17_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_18_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_19_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_1_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_20_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_2_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_3_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_4_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_5_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_6_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_7_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_8_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_9_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_created_at_idx ON payload.payload_locked_documents USING btree (created_at);

CREATE INDEX payload_locked_documents_global_slug_10_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_11_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_12_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_13_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_14_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_15_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_16_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_17_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_18_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_19_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_1_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_20_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_2_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_3_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_4_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_5_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_6_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_7_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_8_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_9_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE INDEX payload_locked_documents_global_slug_idx ON payload.payload_locked_documents USING btree (global_slug);

CREATE UNIQUE INDEX payload_locked_documents_pkey ON payload.payload_locked_documents USING btree (id);

CREATE INDEX payload_locked_documents_rels_categories_id_idx ON payload.payload_locked_documents_rels USING btree (categories_id);

CREATE INDEX payload_locked_documents_rels_form_submissions_id_idx ON payload.payload_locked_documents_rels USING btree (form_submissions_id);

CREATE INDEX payload_locked_documents_rels_forms_id_idx ON payload.payload_locked_documents_rels USING btree (forms_id);

CREATE INDEX payload_locked_documents_rels_media_id_idx ON payload.payload_locked_documents_rels USING btree (media_id);

CREATE INDEX payload_locked_documents_rels_order_idx ON payload.payload_locked_documents_rels USING btree ("order");

CREATE INDEX payload_locked_documents_rels_parent_idx ON payload.payload_locked_documents_rels USING btree (parent_id);

CREATE INDEX payload_locked_documents_rels_path_idx ON payload.payload_locked_documents_rels USING btree (path);

CREATE UNIQUE INDEX payload_locked_documents_rels_pkey ON payload.payload_locked_documents_rels USING btree (id);

CREATE INDEX payload_locked_documents_rels_posts_id_10_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_11_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_12_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_13_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_14_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_15_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_16_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_17_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_18_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_19_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_1_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_20_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_2_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_3_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_4_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_5_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_6_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_7_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_8_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_9_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_posts_id_idx ON payload.payload_locked_documents_rels USING btree (posts_id);

CREATE INDEX payload_locked_documents_rels_redirects_id_idx ON payload.payload_locked_documents_rels USING btree (redirects_id);

CREATE INDEX payload_locked_documents_rels_search_id_idx ON payload.payload_locked_documents_rels USING btree (search_id);

CREATE INDEX payload_locked_documents_rels_users_id_10_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_11_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_12_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_13_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_14_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_15_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_16_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_17_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_18_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_19_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_1_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_20_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_2_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_3_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_4_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_5_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_6_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_7_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_8_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_9_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_rels_users_id_idx ON payload.payload_locked_documents_rels USING btree (users_id);

CREATE INDEX payload_locked_documents_updated_at_10_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_11_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_12_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_13_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_14_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_15_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_16_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_17_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_18_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_19_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_1_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_20_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_2_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_3_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_4_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_5_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_6_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_7_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_8_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_9_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_locked_documents_updated_at_idx ON payload.payload_locked_documents USING btree (updated_at);

CREATE INDEX payload_migrations_created_at_10_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_11_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_12_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_13_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_14_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_15_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_16_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_17_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_18_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_19_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_1_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_20_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_2_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_3_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_4_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_5_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_6_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_7_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_8_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_9_idx ON payload.payload_migrations USING btree (created_at);

CREATE INDEX payload_migrations_created_at_idx ON payload.payload_migrations USING btree (created_at);

CREATE UNIQUE INDEX payload_migrations_pkey ON payload.payload_migrations USING btree (id);

CREATE INDEX payload_migrations_updated_at_10_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_11_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_12_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_13_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_14_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_15_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_16_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_17_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_18_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_19_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_1_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_20_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_2_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_3_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_4_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_5_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_6_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_7_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_8_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_9_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_migrations_updated_at_idx ON payload.payload_migrations USING btree (updated_at);

CREATE INDEX payload_preferences_created_at_10_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_11_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_12_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_13_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_14_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_15_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_16_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_17_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_18_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_19_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_1_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_20_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_2_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_3_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_4_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_5_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_6_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_7_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_8_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_9_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_created_at_idx ON payload.payload_preferences USING btree (created_at);

CREATE INDEX payload_preferences_key_10_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_11_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_12_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_13_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_14_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_15_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_16_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_17_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_18_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_19_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_1_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_20_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_2_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_3_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_4_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_5_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_6_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_7_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_8_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_9_idx ON payload.payload_preferences USING btree (key);

CREATE INDEX payload_preferences_key_idx ON payload.payload_preferences USING btree (key);

CREATE UNIQUE INDEX payload_preferences_pkey ON payload.payload_preferences USING btree (id);

CREATE INDEX payload_preferences_rels_order_idx ON payload.payload_preferences_rels USING btree ("order");

CREATE INDEX payload_preferences_rels_parent_idx ON payload.payload_preferences_rels USING btree (parent_id);

CREATE INDEX payload_preferences_rels_path_idx ON payload.payload_preferences_rels USING btree (path);

CREATE UNIQUE INDEX payload_preferences_rels_pkey ON payload.payload_preferences_rels USING btree (id);

CREATE INDEX payload_preferences_rels_users_id_10_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_11_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_12_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_13_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_14_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_15_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_16_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_17_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_18_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_19_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_1_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_20_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_2_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_3_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_4_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_5_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_6_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_7_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_8_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_9_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_rels_users_id_idx ON payload.payload_preferences_rels USING btree (users_id);

CREATE INDEX payload_preferences_updated_at_10_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_11_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_12_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_13_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_14_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_15_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_16_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_17_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_18_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_19_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_1_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_20_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_2_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_3_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_4_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_5_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_6_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_7_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_8_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_9_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX payload_preferences_updated_at_idx ON payload.payload_preferences USING btree (updated_at);

CREATE INDEX posts__status_10_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_11_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_12_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_1_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_2_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_3_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_4_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_5_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_6_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_7_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_8_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_9_idx ON payload.posts USING btree (_status);

CREATE INDEX posts__status_idx ON payload.posts USING btree (_status);

CREATE INDEX posts_created_at_10_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_11_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_12_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_13_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_14_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_15_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_16_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_17_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_18_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_19_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_1_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_20_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_2_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_3_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_4_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_5_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_6_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_7_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_8_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_9_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_created_at_idx ON payload.posts USING btree (created_at);

CREATE INDEX posts_hero_image_idx ON payload.posts USING btree (hero_image_id);

CREATE INDEX posts_meta_meta_image_idx ON payload.posts USING btree (meta_image_id);

CREATE UNIQUE INDEX posts_pkey ON payload.posts USING btree (id);

CREATE INDEX posts_populated_authors_order_idx ON payload.posts_populated_authors USING btree (_order);

CREATE INDEX posts_populated_authors_parent_id_idx ON payload.posts_populated_authors USING btree (_parent_id);

CREATE UNIQUE INDEX posts_populated_authors_pkey ON payload.posts_populated_authors USING btree (id);

CREATE INDEX posts_rels_categories_id_idx ON payload.posts_rels USING btree (categories_id);

CREATE INDEX posts_rels_order_idx ON payload.posts_rels USING btree ("order");

CREATE INDEX posts_rels_parent_idx ON payload.posts_rels USING btree (parent_id);

CREATE INDEX posts_rels_path_idx ON payload.posts_rels USING btree (path);

CREATE UNIQUE INDEX posts_rels_pkey ON payload.posts_rels USING btree (id);

CREATE INDEX posts_rels_posts_id_idx ON payload.posts_rels USING btree (posts_id);

CREATE INDEX posts_rels_users_id_idx ON payload.posts_rels USING btree (users_id);

CREATE UNIQUE INDEX posts_slug_10_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_11_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_12_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_13_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_14_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_15_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_16_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_17_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_18_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_19_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_1_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_20_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_2_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_3_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_4_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_5_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_6_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_7_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_8_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_9_idx ON payload.posts USING btree (slug);

CREATE UNIQUE INDEX posts_slug_idx ON payload.posts USING btree (slug);

CREATE INDEX posts_updated_at_10_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_11_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_12_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_13_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_14_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_15_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_16_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_17_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_18_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_19_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_1_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_20_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_2_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_3_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_4_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_5_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_6_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_7_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_8_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_9_idx ON payload.posts USING btree (updated_at);

CREATE INDEX posts_updated_at_idx ON payload.posts USING btree (updated_at);

CREATE INDEX redirects_created_at_idx ON payload.redirects USING btree (created_at);

CREATE INDEX redirects_from_idx ON payload.redirects USING btree ("from");

CREATE UNIQUE INDEX redirects_pkey ON payload.redirects USING btree (id);

CREATE INDEX redirects_rels_order_idx ON payload.redirects_rels USING btree ("order");

CREATE INDEX redirects_rels_parent_idx ON payload.redirects_rels USING btree (parent_id);

CREATE INDEX redirects_rels_path_idx ON payload.redirects_rels USING btree (path);

CREATE UNIQUE INDEX redirects_rels_pkey ON payload.redirects_rels USING btree (id);

CREATE INDEX redirects_rels_posts_id_idx ON payload.redirects_rels USING btree (posts_id);

CREATE INDEX redirects_updated_at_idx ON payload.redirects USING btree (updated_at);

CREATE INDEX search_categories_order_idx ON payload.search_categories USING btree (_order);

CREATE INDEX search_categories_parent_id_idx ON payload.search_categories USING btree (_parent_id);

CREATE UNIQUE INDEX search_categories_pkey ON payload.search_categories USING btree (id);

CREATE INDEX search_created_at_idx ON payload.search USING btree (created_at);

CREATE INDEX search_meta_meta_image_idx ON payload.search USING btree (meta_image_id);

CREATE UNIQUE INDEX search_pkey ON payload.search USING btree (id);

CREATE INDEX search_rels_order_idx ON payload.search_rels USING btree ("order");

CREATE INDEX search_rels_parent_idx ON payload.search_rels USING btree (parent_id);

CREATE INDEX search_rels_path_idx ON payload.search_rels USING btree (path);

CREATE UNIQUE INDEX search_rels_pkey ON payload.search_rels USING btree (id);

CREATE INDEX search_rels_posts_id_idx ON payload.search_rels USING btree (posts_id);

CREATE INDEX search_slug_idx ON payload.search USING btree (slug);

CREATE INDEX search_updated_at_idx ON payload.search USING btree (updated_at);

CREATE INDEX users_created_at_10_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_11_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_12_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_13_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_14_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_15_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_16_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_17_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_18_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_19_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_1_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_20_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_2_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_3_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_4_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_5_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_6_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_7_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_8_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_9_idx ON payload.users USING btree (created_at);

CREATE INDEX users_created_at_idx ON payload.users USING btree (created_at);

CREATE UNIQUE INDEX users_email_10_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_11_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_12_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_13_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_14_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_15_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_16_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_17_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_18_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_19_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_1_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_20_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_2_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_3_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_4_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_5_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_6_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_7_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_8_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_9_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_email_idx ON payload.users USING btree (email);

CREATE UNIQUE INDEX users_pkey ON payload.users USING btree (id);

CREATE INDEX users_updated_at_10_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_11_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_12_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_13_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_14_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_15_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_16_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_17_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_18_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_19_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_1_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_20_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_2_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_3_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_4_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_5_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_6_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_7_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_8_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_9_idx ON payload.users USING btree (updated_at);

CREATE INDEX users_updated_at_idx ON payload.users USING btree (updated_at);

alter table "payload"."_posts_v" add constraint "_posts_v_pkey" PRIMARY KEY using index "_posts_v_pkey";

alter table "payload"."_posts_v_rels" add constraint "_posts_v_rels_pkey" PRIMARY KEY using index "_posts_v_rels_pkey";

alter table "payload"."_posts_v_version_populated_authors" add constraint "_posts_v_version_populated_authors_pkey" PRIMARY KEY using index "_posts_v_version_populated_authors_pkey";

alter table "payload"."categories" add constraint "categories_pkey" PRIMARY KEY using index "categories_pkey";

alter table "payload"."categories_breadcrumbs" add constraint "categories_breadcrumbs_pkey" PRIMARY KEY using index "categories_breadcrumbs_pkey";

alter table "payload"."form_submissions" add constraint "form_submissions_pkey" PRIMARY KEY using index "form_submissions_pkey";

alter table "payload"."form_submissions_submission_data" add constraint "form_submissions_submission_data_pkey" PRIMARY KEY using index "form_submissions_submission_data_pkey";

alter table "payload"."forms" add constraint "forms_pkey" PRIMARY KEY using index "forms_pkey";

alter table "payload"."forms_blocks_checkbox" add constraint "forms_blocks_checkbox_pkey" PRIMARY KEY using index "forms_blocks_checkbox_pkey";

alter table "payload"."forms_blocks_country" add constraint "forms_blocks_country_pkey" PRIMARY KEY using index "forms_blocks_country_pkey";

alter table "payload"."forms_blocks_email" add constraint "forms_blocks_email_pkey" PRIMARY KEY using index "forms_blocks_email_pkey";

alter table "payload"."forms_blocks_message" add constraint "forms_blocks_message_pkey" PRIMARY KEY using index "forms_blocks_message_pkey";

alter table "payload"."forms_blocks_number" add constraint "forms_blocks_number_pkey" PRIMARY KEY using index "forms_blocks_number_pkey";

alter table "payload"."forms_blocks_select" add constraint "forms_blocks_select_pkey" PRIMARY KEY using index "forms_blocks_select_pkey";

alter table "payload"."forms_blocks_select_options" add constraint "forms_blocks_select_options_pkey" PRIMARY KEY using index "forms_blocks_select_options_pkey";

alter table "payload"."forms_blocks_state" add constraint "forms_blocks_state_pkey" PRIMARY KEY using index "forms_blocks_state_pkey";

alter table "payload"."forms_blocks_text" add constraint "forms_blocks_text_pkey" PRIMARY KEY using index "forms_blocks_text_pkey";

alter table "payload"."forms_blocks_textarea" add constraint "forms_blocks_textarea_pkey" PRIMARY KEY using index "forms_blocks_textarea_pkey";

alter table "payload"."forms_emails" add constraint "forms_emails_pkey" PRIMARY KEY using index "forms_emails_pkey";

alter table "payload"."media" add constraint "media_pkey" PRIMARY KEY using index "media_pkey";

alter table "payload"."payload_locked_documents" add constraint "payload_locked_documents_pkey" PRIMARY KEY using index "payload_locked_documents_pkey";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_pkey" PRIMARY KEY using index "payload_locked_documents_rels_pkey";

alter table "payload"."payload_migrations" add constraint "payload_migrations_pkey" PRIMARY KEY using index "payload_migrations_pkey";

alter table "payload"."payload_preferences" add constraint "payload_preferences_pkey" PRIMARY KEY using index "payload_preferences_pkey";

alter table "payload"."payload_preferences_rels" add constraint "payload_preferences_rels_pkey" PRIMARY KEY using index "payload_preferences_rels_pkey";

alter table "payload"."posts" add constraint "posts_pkey" PRIMARY KEY using index "posts_pkey";

alter table "payload"."posts_populated_authors" add constraint "posts_populated_authors_pkey" PRIMARY KEY using index "posts_populated_authors_pkey";

alter table "payload"."posts_rels" add constraint "posts_rels_pkey" PRIMARY KEY using index "posts_rels_pkey";

alter table "payload"."redirects" add constraint "redirects_pkey" PRIMARY KEY using index "redirects_pkey";

alter table "payload"."redirects_rels" add constraint "redirects_rels_pkey" PRIMARY KEY using index "redirects_rels_pkey";

alter table "payload"."search" add constraint "search_pkey" PRIMARY KEY using index "search_pkey";

alter table "payload"."search_categories" add constraint "search_categories_pkey" PRIMARY KEY using index "search_categories_pkey";

alter table "payload"."search_rels" add constraint "search_rels_pkey" PRIMARY KEY using index "search_rels_pkey";

alter table "payload"."users" add constraint "users_pkey" PRIMARY KEY using index "users_pkey";

alter table "payload"."_posts_v" add constraint "_posts_v_parent_id_posts_id_fk" FOREIGN KEY (parent_id) REFERENCES payload.posts(id) ON DELETE SET NULL not valid;

alter table "payload"."_posts_v" validate constraint "_posts_v_parent_id_posts_id_fk";

alter table "payload"."_posts_v" add constraint "_posts_v_version_hero_image_id_media_id_fk" FOREIGN KEY (version_hero_image_id) REFERENCES payload.media(id) ON DELETE SET NULL not valid;

alter table "payload"."_posts_v" validate constraint "_posts_v_version_hero_image_id_media_id_fk";

alter table "payload"."_posts_v" add constraint "_posts_v_version_meta_image_id_media_id_fk" FOREIGN KEY (version_meta_image_id) REFERENCES payload.media(id) ON DELETE SET NULL not valid;

alter table "payload"."_posts_v" validate constraint "_posts_v_version_meta_image_id_media_id_fk";

alter table "payload"."_posts_v_rels" add constraint "_posts_v_rels_categories_fk" FOREIGN KEY (categories_id) REFERENCES payload.categories(id) ON DELETE CASCADE not valid;

alter table "payload"."_posts_v_rels" validate constraint "_posts_v_rels_categories_fk";

alter table "payload"."_posts_v_rels" add constraint "_posts_v_rels_parent_fk" FOREIGN KEY (parent_id) REFERENCES payload._posts_v(id) ON DELETE CASCADE not valid;

alter table "payload"."_posts_v_rels" validate constraint "_posts_v_rels_parent_fk";

alter table "payload"."_posts_v_rels" add constraint "_posts_v_rels_posts_fk" FOREIGN KEY (posts_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."_posts_v_rels" validate constraint "_posts_v_rels_posts_fk";

alter table "payload"."_posts_v_rels" add constraint "_posts_v_rels_users_fk" FOREIGN KEY (users_id) REFERENCES payload.users(id) ON DELETE CASCADE not valid;

alter table "payload"."_posts_v_rels" validate constraint "_posts_v_rels_users_fk";

alter table "payload"."_posts_v_version_populated_authors" add constraint "_posts_v_version_populated_authors_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload._posts_v(id) ON DELETE CASCADE not valid;

alter table "payload"."_posts_v_version_populated_authors" validate constraint "_posts_v_version_populated_authors_parent_id_fk";

alter table "payload"."categories" add constraint "categories_parent_id_categories_id_fk" FOREIGN KEY (parent_id) REFERENCES payload.categories(id) ON DELETE SET NULL not valid;

alter table "payload"."categories" validate constraint "categories_parent_id_categories_id_fk";

alter table "payload"."categories_breadcrumbs" add constraint "categories_breadcrumbs_doc_id_categories_id_fk" FOREIGN KEY (doc_id) REFERENCES payload.categories(id) ON DELETE SET NULL not valid;

alter table "payload"."categories_breadcrumbs" validate constraint "categories_breadcrumbs_doc_id_categories_id_fk";

alter table "payload"."categories_breadcrumbs" add constraint "categories_breadcrumbs_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.categories(id) ON DELETE CASCADE not valid;

alter table "payload"."categories_breadcrumbs" validate constraint "categories_breadcrumbs_parent_id_fk";

alter table "payload"."form_submissions" add constraint "form_submissions_form_id_forms_id_fk" FOREIGN KEY (form_id) REFERENCES payload.forms(id) ON DELETE SET NULL not valid;

alter table "payload"."form_submissions" validate constraint "form_submissions_form_id_forms_id_fk";

alter table "payload"."form_submissions_submission_data" add constraint "form_submissions_submission_data_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.form_submissions(id) ON DELETE CASCADE not valid;

alter table "payload"."form_submissions_submission_data" validate constraint "form_submissions_submission_data_parent_id_fk";

alter table "payload"."forms_blocks_checkbox" add constraint "forms_blocks_checkbox_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_checkbox" validate constraint "forms_blocks_checkbox_parent_id_fk";

alter table "payload"."forms_blocks_country" add constraint "forms_blocks_country_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_country" validate constraint "forms_blocks_country_parent_id_fk";

alter table "payload"."forms_blocks_email" add constraint "forms_blocks_email_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_email" validate constraint "forms_blocks_email_parent_id_fk";

alter table "payload"."forms_blocks_message" add constraint "forms_blocks_message_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_message" validate constraint "forms_blocks_message_parent_id_fk";

alter table "payload"."forms_blocks_number" add constraint "forms_blocks_number_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_number" validate constraint "forms_blocks_number_parent_id_fk";

alter table "payload"."forms_blocks_select" add constraint "forms_blocks_select_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_select" validate constraint "forms_blocks_select_parent_id_fk";

alter table "payload"."forms_blocks_select_options" add constraint "forms_blocks_select_options_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms_blocks_select(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_select_options" validate constraint "forms_blocks_select_options_parent_id_fk";

alter table "payload"."forms_blocks_state" add constraint "forms_blocks_state_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_state" validate constraint "forms_blocks_state_parent_id_fk";

alter table "payload"."forms_blocks_text" add constraint "forms_blocks_text_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_text" validate constraint "forms_blocks_text_parent_id_fk";

alter table "payload"."forms_blocks_textarea" add constraint "forms_blocks_textarea_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_blocks_textarea" validate constraint "forms_blocks_textarea_parent_id_fk";

alter table "payload"."forms_emails" add constraint "forms_emails_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."forms_emails" validate constraint "forms_emails_parent_id_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_categories_fk" FOREIGN KEY (categories_id) REFERENCES payload.categories(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_categories_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_form_submissions_fk" FOREIGN KEY (form_submissions_id) REFERENCES payload.form_submissions(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_form_submissions_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_forms_fk" FOREIGN KEY (forms_id) REFERENCES payload.forms(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_forms_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_media_fk" FOREIGN KEY (media_id) REFERENCES payload.media(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_media_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_parent_fk" FOREIGN KEY (parent_id) REFERENCES payload.payload_locked_documents(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_parent_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_posts_fk" FOREIGN KEY (posts_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_posts_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_redirects_fk" FOREIGN KEY (redirects_id) REFERENCES payload.redirects(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_redirects_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_search_fk" FOREIGN KEY (search_id) REFERENCES payload.search(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_search_fk";

alter table "payload"."payload_locked_documents_rels" add constraint "payload_locked_documents_rels_users_fk" FOREIGN KEY (users_id) REFERENCES payload.users(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_locked_documents_rels" validate constraint "payload_locked_documents_rels_users_fk";

alter table "payload"."payload_preferences_rels" add constraint "payload_preferences_rels_parent_fk" FOREIGN KEY (parent_id) REFERENCES payload.payload_preferences(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_preferences_rels" validate constraint "payload_preferences_rels_parent_fk";

alter table "payload"."payload_preferences_rels" add constraint "payload_preferences_rels_users_fk" FOREIGN KEY (users_id) REFERENCES payload.users(id) ON DELETE CASCADE not valid;

alter table "payload"."payload_preferences_rels" validate constraint "payload_preferences_rels_users_fk";

alter table "payload"."posts" add constraint "posts_hero_image_id_media_id_fk" FOREIGN KEY (hero_image_id) REFERENCES payload.media(id) ON DELETE SET NULL not valid;

alter table "payload"."posts" validate constraint "posts_hero_image_id_media_id_fk";

alter table "payload"."posts" add constraint "posts_meta_image_id_media_id_fk" FOREIGN KEY (meta_image_id) REFERENCES payload.media(id) ON DELETE SET NULL not valid;

alter table "payload"."posts" validate constraint "posts_meta_image_id_media_id_fk";

alter table "payload"."posts_populated_authors" add constraint "posts_populated_authors_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."posts_populated_authors" validate constraint "posts_populated_authors_parent_id_fk";

alter table "payload"."posts_rels" add constraint "posts_rels_categories_fk" FOREIGN KEY (categories_id) REFERENCES payload.categories(id) ON DELETE CASCADE not valid;

alter table "payload"."posts_rels" validate constraint "posts_rels_categories_fk";

alter table "payload"."posts_rels" add constraint "posts_rels_parent_fk" FOREIGN KEY (parent_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."posts_rels" validate constraint "posts_rels_parent_fk";

alter table "payload"."posts_rels" add constraint "posts_rels_posts_fk" FOREIGN KEY (posts_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."posts_rels" validate constraint "posts_rels_posts_fk";

alter table "payload"."posts_rels" add constraint "posts_rels_users_fk" FOREIGN KEY (users_id) REFERENCES payload.users(id) ON DELETE CASCADE not valid;

alter table "payload"."posts_rels" validate constraint "posts_rels_users_fk";

alter table "payload"."redirects_rels" add constraint "redirects_rels_parent_fk" FOREIGN KEY (parent_id) REFERENCES payload.redirects(id) ON DELETE CASCADE not valid;

alter table "payload"."redirects_rels" validate constraint "redirects_rels_parent_fk";

alter table "payload"."redirects_rels" add constraint "redirects_rels_posts_fk" FOREIGN KEY (posts_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."redirects_rels" validate constraint "redirects_rels_posts_fk";

alter table "payload"."search" add constraint "search_meta_image_id_media_id_fk" FOREIGN KEY (meta_image_id) REFERENCES payload.media(id) ON DELETE SET NULL not valid;

alter table "payload"."search" validate constraint "search_meta_image_id_media_id_fk";

alter table "payload"."search_categories" add constraint "search_categories_parent_id_fk" FOREIGN KEY (_parent_id) REFERENCES payload.search(id) ON DELETE CASCADE not valid;

alter table "payload"."search_categories" validate constraint "search_categories_parent_id_fk";

alter table "payload"."search_rels" add constraint "search_rels_parent_fk" FOREIGN KEY (parent_id) REFERENCES payload.search(id) ON DELETE CASCADE not valid;

alter table "payload"."search_rels" validate constraint "search_rels_parent_fk";

alter table "payload"."search_rels" add constraint "search_rels_posts_fk" FOREIGN KEY (posts_id) REFERENCES payload.posts(id) ON DELETE CASCADE not valid;

alter table "payload"."search_rels" validate constraint "search_rels_posts_fk";

-- Storage
insert into storage.buckets
  (id, name, public, file_size_limit)
values
  ('media-payload', 'media-payload', true, 10485760);
