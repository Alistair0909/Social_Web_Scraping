CREATE TYPE website_source_type AS ENUM (
    'instagram', 
    'linkedin', 
    'threads', 
    'facebook', 
    'tiktok', 
    'generic'
);

CREATE TABLE IF NOT EXISTS website_data_sources (
    id SERIAL PRIMARY KEY,
    entry_url TEXT NOT NULL,
    name TEXT,
    description TEXT,
    type website_source_type NOT NULL DEFAULT 'generic',
    metadata JSONB DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS website_data_scrape_cache (
    id SERIAL PRIMARY KEY,
    scrape_time TIMESTAMPTZ NOT NULL DEFAULT now(),
    data JSONB DEFAULT '{}'::jsonb
);

-- Create brands table
CREATE TABLE IF NOT EXISTS brands (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    website_url TEXT,
    logo_url TEXT,
    description TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE DEFAULT auth.uid(),
    is_active BOOLEAN DEFAULT true
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_brands_user_id ON brands(user_id);

-- Add RLS (Row Level Security) policies
ALTER TABLE brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE website_data_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE website_data_scrape_cache ENABLE ROW LEVEL SECURITY;

-- Create policies for brands table
CREATE POLICY "Users can view their own brands" 
    ON brands FOR SELECT 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own brands" 
    ON brands FOR INSERT 
    WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own brands" 
    ON brands FOR UPDATE 
    USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own brands" 
    ON brands FOR DELETE 
    USING (auth.uid() = user_id);

-- Create triggers for updated_at
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_brands_modtime
BEFORE UPDATE ON brands
FOR EACH ROW
EXECUTE FUNCTION update_modified_column();

