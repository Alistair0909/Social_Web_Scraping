CREATE EXTENSION pg_jsonschema;

CREATE TABLE public.social_profiles (
  id SERIAL PRIMARY KEY,
  name TEXT,
  last_scraped_at TIMESTAMPTZ DEFAULT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  social_url TEXT,
  social_handle TEXT,
  platform TEXT,
  followers INT,
  impact FLOAT,
  should_scrape BOOLEAN
);

ALTER TABLE public.social_profiles ENABLE ROW LEVEL SECURITY;

-- Create a function that will be called by the trigger for social profiles
CREATE OR REPLACE FUNCTION public.fn_queue_social_profile_for_crawling()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path=''
AS $function$
BEGIN
  -- Only queue for crawling if should_scrape is true
  IF NEW.should_scrape = TRUE THEN
    -- Add the social profile to the crawler_requests queue
    PERFORM pgmq_public.send(
      'crawler_requests',
      jsonb_build_object(
        'profileId', NEW.id,
        'crawlType', 'social_profile',
        'platform', NEW.platform,
        'socialHandle', NEW.social_handle,
        'socialUrl', NEW.social_url
      )
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create the trigger on the social_profiles table
CREATE TRIGGER trg_queue_social_profile_for_crawling
  AFTER INSERT OR UPDATE OF should_scrape
  ON public.social_profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_queue_social_profile_for_crawling();

CREATE TABLE public.social_posts (
  id SERIAL PRIMARY KEY,
  social_profile_id INT REFERENCES public.social_profiles(id) ON DELETE CASCADE,
  sentiment JSONB NOT NULL,
  content_text TEXT,
  last_scraped_at TIMESTAMPTZ DEFAULT now(),
  metadata JSONB NOT NULL,
  url TEXT UNIQUE,

  check (
    jsonb_matches_schema(
      schema :='{
        "type": "object",
        "properties": {
          "positive": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "negative": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          },
          "neutral": {
            "type": "number",
            "minimum": 0,
            "maximum": 1
          }
        },
        "required": ["positive", "negative", "neutral"],
        "additionalProperties": false
      }',
      instance := sentiment
    )
  ),

  check (
    jsonb_matches_schema(
      schema :='{
        "type": "object",
        "properties": {
          "media_urls": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "type": {
                  "enum": ["video", "image"]
                },
                "url": {
                  "type": "string"
                }
              }
            }
          },
          "tags": {
            "type": "array",
            "items": {
              "type": "object",
              "properties": {
                "name": {
                  "type": "string"
                },
                "url": {
                  "type": "string"
                }
              }
            }
          }
        },
        "required": ["media_urls", "tags"],
        "additionalProperties": false
      }',
      instance := metadata
    )
  )
);

ALTER TABLE public.social_posts ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.social_posts_comments (
  id SERIAL PRIMARY KEY,
  social_post_id INT REFERENCES public.social_posts(id) ON DELETE CASCADE,
  sentiment FLOAT,
  content_text TEXT,
  social_profile_id INT REFERENCES public.social_profiles(id) ON DELETE CASCADE
);

ALTER TABLE public.social_posts_comments ENABLE ROW LEVEL SECURITY;

CREATE TYPE public.post_relation_type AS ENUM (
  'tagged_in',
  'mentioned_in',
  'showcased_on_media_in'
);

CREATE TABLE public.social_posts_brands (
  id SERIAL PRIMARY KEY,
  brand_id INT REFERENCES public.brands(id) ON DELETE CASCADE,
  social_post_id INT REFERENCES public.social_posts(id) ON DELETE CASCADE,
  relation_type public.post_relation_type NOT NULL
);

ALTER TABLE public.social_posts_brands ENABLE ROW LEVEL SECURITY;
