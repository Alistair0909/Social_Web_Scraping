-- Create a function that will be called by the trigger
CREATE OR REPLACE FUNCTION public.fn_queue_company_for_crawling()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path=''
AS $function$
BEGIN
  -- Add the new company to the crawler_requests queue only if it hasn't been crawled in the last 30 minutes
  IF NOT EXISTS (
    SELECT 1 
    FROM pgmq.read(queue_name => 'crawler_requests', vt => 0, qty => 1) el
    WHERE el.message->>'id'::text = NEW.id::text
    AND el.enqueued_at > NOW() - INTERVAL '30 minutes'
  ) THEN
    PERFORM pgmq_public.send(
      'crawler_requests',
      jsonb_build_object(
        'companyId', NEW.id,
        'crawlType', 'company_research',
        'companyName', NEW.name,
        'companyDescription', COALESCE(NEW.description, ''),
        'search', TRUE,
        'additionalSources', jsonb_build_array()
      )
    );
  END IF;
  
  RETURN NEW;
END;
$function$;

-- Create the trigger on the companies table
CREATE TRIGGER trg_queue_company_for_crawling
  AFTER INSERT
  ON public.brands
  FOR EACH ROW
  EXECUTE FUNCTION public.fn_queue_company_for_crawling();


