import fs from "fs/promises";
import path from "path";

const leftPadChar = (string: string, char: string, length: number) => {
  return char.repeat(length - string.length) + string;
};

const __dirname = path.dirname(new URL(import.meta.url).pathname);

const migrationsDir = path.join(__dirname, "..", "migrations");
const testUtilsFilePath = path.join(
  __dirname,
  "..",
  "snippets",
  "test_utils.sql",
);

const testUtilsMigrationFileRegex = /^(\d+)_test_utils\.sql$/;

export async function removeTestUtilsMigration() {
  const files = await fs.readdir(migrationsDir);
  let hasTestUtilsMigration = false;

  for (const file of files) {
    if (testUtilsMigrationFileRegex.test(file)) {
      console.log("🗑️  Removing existing test migration file: ", file);
      hasTestUtilsMigration = true;
      await fs.rm(path.join(migrationsDir, file));
    }
  }

  if (!hasTestUtilsMigration) {
    console.log("✅ No existing test migration file found.");
  }
}

export async function createTestMigration() {
  const files = await fs.readdir(migrationsDir);
  const lastMigration =
    files
      .map((file) => parseInt(file.split("_")[0] ?? "0"))
      .sort((a, b) => b - a)[0] ?? 0;
  const nextMigration = leftPadChar(`${lastMigration + 1}`, "0", 14);
  const nextMigrationFile = `${nextMigration}_test_utils.sql`;

  console.log("🛠️  Creating test migration file: ", nextMigrationFile);

  await fs.cp(testUtilsFilePath, path.join(migrationsDir, nextMigrationFile));

  console.log("🎉 Test file created");
}
