import { createTestMigration, removeTestUtilsMigration } from "./helpers";

async function main() {
  await removeTestUtilsMigration();
  await createTestMigration();
}

void main();
