import { createSeedClient } from "@snaplet/seed";

import instagramData from "./data/initial-instagram-profiles.json";

async function main() {
  const seed = await createSeedClient({ dryRun: true });

  await seed.social_profiles(
    instagramData
      .map((p) => ({
        name: p.full_name,
        last_scraped_at: null,
        social_url: p.url,
        followers: p.followers,
        platform: "instagram",
        social_handle: p.account,
        impact: null,
        should_scrape: true,
      }))
      .filter((p) => Boolean(p.social_url)),
  );

  process.exit();
}

void main();
