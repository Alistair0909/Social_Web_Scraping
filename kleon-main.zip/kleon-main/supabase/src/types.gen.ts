export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  graphql_public: {
    Tables: {
      [_ in never]: never
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      graphql: {
        Args: {
          operationName?: string
          query?: string
          variables?: Json
          extensions?: Json
        }
        Returns: Json
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
  pgmq_public: {
    Tables: {
      [_ in never]: never
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      archive: {
        Args: {
          queue_name: string
          message_id: number
        }
        Returns: boolean
      }
      delete: {
        Args: {
          queue_name: string
          message_id: number
        }
        Returns: boolean
      }
      pop: {
        Args: {
          queue_name: string
        }
        Returns: unknown[]
      }
      read: {
        Args: {
          queue_name: string
          sleep_seconds: number
          n: number
        }
        Returns: unknown[]
      }
      send: {
        Args: {
          queue_name: string
          message: Json
          sleep_seconds?: number
        }
        Returns: number[]
      }
      send_batch: {
        Args: {
          queue_name: string
          messages: Json[]
          sleep_seconds?: number
        }
        Returns: number[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
  public: {
    Tables: {
      brands: {
        Row: {
          created_at: string
          description: string | null
          id: number
          is_active: boolean | null
          logo_url: string | null
          name: string
          updated_at: string
          user_id: string | null
          website_url: string | null
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: number
          is_active?: boolean | null
          logo_url?: string | null
          name: string
          updated_at?: string
          user_id?: string | null
          website_url?: string | null
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: number
          is_active?: boolean | null
          logo_url?: string | null
          name?: string
          updated_at?: string
          user_id?: string | null
          website_url?: string | null
        }
        Relationships: []
      }
      social_posts: {
        Row: {
          content_text: string | null
          id: number
          last_scraped_at: string | null
          metadata: Json
          sentiment: Json
          social_profile_id: number | null
          url: string | null
        }
        Insert: {
          content_text?: string | null
          id?: number
          last_scraped_at?: string | null
          metadata: Json
          sentiment: Json
          social_profile_id?: number | null
          url?: string | null
        }
        Update: {
          content_text?: string | null
          id?: number
          last_scraped_at?: string | null
          metadata?: Json
          sentiment?: Json
          social_profile_id?: number | null
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "social_posts_social_profile_id_fkey"
            columns: ["social_profile_id"]
            isOneToOne: false
            referencedRelation: "social_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      social_posts_brands: {
        Row: {
          brand_id: number | null
          id: number
          relation_type: Database["public"]["Enums"]["post_relation_type"]
          social_post_id: number | null
        }
        Insert: {
          brand_id?: number | null
          id?: number
          relation_type: Database["public"]["Enums"]["post_relation_type"]
          social_post_id?: number | null
        }
        Update: {
          brand_id?: number | null
          id?: number
          relation_type?: Database["public"]["Enums"]["post_relation_type"]
          social_post_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "social_posts_brands_brand_id_fkey"
            columns: ["brand_id"]
            isOneToOne: false
            referencedRelation: "brands"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "social_posts_brands_social_post_id_fkey"
            columns: ["social_post_id"]
            isOneToOne: false
            referencedRelation: "social_posts"
            referencedColumns: ["id"]
          },
        ]
      }
      social_posts_comments: {
        Row: {
          content_text: string | null
          id: number
          sentiment: number | null
          social_post_id: number | null
          social_profile_id: number | null
        }
        Insert: {
          content_text?: string | null
          id?: number
          sentiment?: number | null
          social_post_id?: number | null
          social_profile_id?: number | null
        }
        Update: {
          content_text?: string | null
          id?: number
          sentiment?: number | null
          social_post_id?: number | null
          social_profile_id?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "social_posts_comments_social_post_id_fkey"
            columns: ["social_post_id"]
            isOneToOne: false
            referencedRelation: "social_posts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "social_posts_comments_social_profile_id_fkey"
            columns: ["social_profile_id"]
            isOneToOne: false
            referencedRelation: "social_profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      social_profiles: {
        Row: {
          created_at: string | null
          followers: number | null
          id: number
          impact: number | null
          last_scraped_at: string | null
          name: string | null
          platform: string | null
          should_scrape: boolean | null
          social_handle: string | null
          social_url: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          followers?: number | null
          id?: number
          impact?: number | null
          last_scraped_at?: string | null
          name?: string | null
          platform?: string | null
          should_scrape?: boolean | null
          social_handle?: string | null
          social_url?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          followers?: number | null
          id?: number
          impact?: number | null
          last_scraped_at?: string | null
          name?: string | null
          platform?: string | null
          should_scrape?: boolean | null
          social_handle?: string | null
          social_url?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      website_data_scrape_cache: {
        Row: {
          data: Json | null
          id: number
          scrape_time: string
        }
        Insert: {
          data?: Json | null
          id?: number
          scrape_time?: string
        }
        Update: {
          data?: Json | null
          id?: number
          scrape_time?: string
        }
        Relationships: []
      }
      website_data_sources: {
        Row: {
          description: string | null
          entry_url: string
          id: number
          metadata: Json | null
          name: string | null
          type: Database["public"]["Enums"]["website_source_type"]
        }
        Insert: {
          description?: string | null
          entry_url: string
          id?: number
          metadata?: Json | null
          name?: string | null
          type?: Database["public"]["Enums"]["website_source_type"]
        }
        Update: {
          description?: string | null
          entry_url?: string
          id?: number
          metadata?: Json | null
          name?: string | null
          type?: Database["public"]["Enums"]["website_source_type"]
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      json_matches_schema: {
        Args: {
          schema: Json
          instance: Json
        }
        Returns: boolean
      }
      jsonb_matches_schema: {
        Args: {
          schema: Json
          instance: Json
        }
        Returns: boolean
      }
      jsonschema_is_valid: {
        Args: {
          schema: Json
        }
        Returns: boolean
      }
      jsonschema_validation_errors: {
        Args: {
          schema: Json
          instance: Json
        }
        Returns: string[]
      }
    }
    Enums: {
      post_relation_type: "tagged_in" | "mentioned_in" | "showcased_on_media_in"
      website_source_type:
        | "instagram"
        | "linkedin"
        | "threads"
        | "facebook"
        | "tiktok"
        | "generic"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  graphql_public: {
    Enums: {},
  },
  pgmq_public: {
    Enums: {},
  },
  public: {
    Enums: {
      post_relation_type: [
        "tagged_in",
        "mentioned_in",
        "showcased_on_media_in",
      ],
      website_source_type: [
        "instagram",
        "linkedin",
        "threads",
        "facebook",
        "tiktok",
        "generic",
      ],
    },
  },
} as const

