import { SeedPg } from "@snaplet/seed/adapter-pg";
import { defineConfig } from "@snaplet/seed/config";
import { Client } from "pg";

const config: unknown = defineConfig({
  adapter: async () => {
    const client = new Client({
      connectionString:
        "postgresql://postgres:postgres@localhost:54322/postgres",
    });
    await client.connect();
    return new SeedPg(client);
  },
  // We only want to generate data for the public schema
  select: ["!*", "public.*", "auth.users", "auth.identities", "auth.sessions"],
});

export default config;
