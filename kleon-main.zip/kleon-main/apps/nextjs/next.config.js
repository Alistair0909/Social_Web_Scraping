import { fileURLToPath } from "url";
import _jiti from "jiti";

const jiti = _jiti(fileURLToPath(import.meta.url));

/**
 * Import env files to validate at build time. Use jiti so we can load .ts files in here.
 * @type {import("@tonik/env")}
 */
jiti("@tonik/env");

/** @type {import("next").NextConfig} */
const config = {
  reactStrictMode: true,

  /** Enables hot reloading for local packages without a build step */
  transpilePackages: [
    "@tonik/env",
    "@tonik/admin-api",
    "@tonik/supabase",
    "@tonik/ui",
    "@tonik/recipes",
    "@tonik/validators",
    "@tonik/payload",
    "@tonik/inngest",
  ],
  env: {
    PORT: process.env.PORT,
  },

  serverExternalPackages: ["sequelize", "pino", "pino-pretty"],

  /** We already do linting and typechecking as separate tasks in CI */
  eslint: { ignoreDuringBuilds: true },
  typescript: { ignoreBuildErrors: true },

  redirects: async () => {
    return [
      {
        source: "/_db",
        destination: "http://localhost:54323",
        basePath: false,
        permanent: false,
      },
      {
        source: "/_otel",
        destination: "http://localhost:16686",
        basePath: false,
        permanent: false,
      },

      {
        source: "/_email",
        destination: "http://localhost:54324",
        basePath: false,
        permanent: false,
      },
    ];
  },
};

export default config;
