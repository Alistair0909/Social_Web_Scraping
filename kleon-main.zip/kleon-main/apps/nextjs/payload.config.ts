export { default } from "@tonik/payload/config";
export * from "@tonik/payload/config";
