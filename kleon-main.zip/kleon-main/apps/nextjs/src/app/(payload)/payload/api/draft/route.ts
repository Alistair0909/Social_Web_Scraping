import { draftMode } from "next/headers";
import { redirect } from "next/navigation";
import { NextRequest } from "next/server";
import { TRPCError } from "@trpc/server";

import { api } from "~/trpc/rsc";

export async function GET(req: NextRequest): Promise<Response> {
  const draft = await draftMode();

  const path = req.nextUrl.searchParams.get("path");

  if (!path) {
    return new Response("Invalid preview path", { status: 400 });
  }

  try {
    const data = await api.payload.draft({
      collection: req.nextUrl.searchParams.get("collection") as "posts",
      slug: req.nextUrl.searchParams.get("slug") as string,
    });

    if (data.totalDocs === 0) {
      return new Response("Document not found", { status: 404 });
    }

    draft.enable();
  } catch (error) {
    console.error("Failed to enable draft", error);
    draft.disable();

    if (error instanceof TRPCError) {
      if (error.code === "UNAUTHORIZED") {
        return new Response("You are not allowed to preview this page", {
          status: 403,
        });
      }
      if (error.code === "NOT_FOUND") {
        return new Response("Document not found", { status: 404 });
      }
    }

    throw error;
  }

  redirect(path);
}
