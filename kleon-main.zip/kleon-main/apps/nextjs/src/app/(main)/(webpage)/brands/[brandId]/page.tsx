import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Edit, Trash } from "lucide-react";

import { Button } from "@tonik/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@tonik/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@tonik/ui/tabs";

import { api } from "~/trpc/rsc";

async function BrandPage({ params }: { params: { brandId: string } }) {
  console.log(params);
  const id = parseInt(params.brandId);

  if (isNaN(id)) notFound();

  const brand = await api.brand.getById({ id });

  if (!brand) notFound();

  return (
    <div className="container mx-auto py-8">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Brands
            </Button>
          </Link>
          <h1 className="text-3xl font-bold">{brand.name}</h1>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </Button>
          <Button variant="destructive" size="sm">
            <Trash className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Brand Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="mb-4 flex justify-center">
                <div className="flex h-32 w-32 items-center justify-center rounded-full bg-gray-200 text-gray-500">
                  Logo
                </div>
              </div>
              <div className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    Description
                  </h3>
                  <p>{brand.description}</p>
                </div>
                {brand.website_url && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">
                      Website
                    </h3>
                    <a
                      href={brand.website_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 hover:underline"
                    >
                      {brand.website_url}
                    </a>
                  </div>
                )}
                <div>
                  <h3 className="text-sm font-medium text-gray-500">Created</h3>
                  <p>{new Date(brand.created_at).toLocaleDateString()}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-gray-500">
                    Last Updated
                  </h3>
                  <p>{new Date(brand.updated_at).toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="md:col-span-2">
          <Tabs defaultValue="products">
            <TabsList className="mb-4">
              <TabsTrigger value="products">Products</TabsTrigger>
              <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="products">
              <Card>
                <CardHeader>
                  <CardTitle>Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border p-8 text-center">
                    <p className="text-gray-500">
                      No products found for this brand.
                    </p>
                    <Button className="mt-4">Add Product</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="campaigns">
              <Card>
                <CardHeader>
                  <CardTitle>Campaigns</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="rounded-md border p-8 text-center">
                    <p className="text-gray-500">
                      No campaigns found for this brand.
                    </p>
                    <Button className="mt-4">Create Campaign</Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics">
              <Card>
                <CardHeader>
                  <CardTitle>Analytics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div className="rounded-md border p-4">
                      <h3 className="mb-2 font-medium">Impressions</h3>
                      <p className="text-2xl font-bold">0</p>
                    </div>
                    <div className="rounded-md border p-4">
                      <h3 className="mb-2 font-medium">Clicks</h3>
                      <p className="text-2xl font-bold">0</p>
                    </div>
                    <div className="rounded-md border p-4">
                      <h3 className="mb-2 font-medium">Conversions</h3>
                      <p className="text-2xl font-bold">0</p>
                    </div>
                    <div className="rounded-md border p-4">
                      <h3 className="mb-2 font-medium">Revenue</h3>
                      <p className="text-2xl font-bold">$0.00</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

export default BrandPage;
