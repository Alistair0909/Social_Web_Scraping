"use client";

import { useRouter } from "next/navigation";
import { toast } from "sonner";

import { api } from "~/trpc/react";
import { BrandCard, type Brand } from "./brand-card";

export const BrandsList = () => {
  const router = useRouter();
  const { isLoading, error, data: brands } = api.brand.list.useQuery(undefined);
  const utils = api.useUtils();

  const deleteBrandMutation = api.brand.delete.useMutation({
    onSuccess: () => {
      toast.success("Brand deleted successfully");
      void utils.brand.list.invalidate();
    },
    onError: (error) => {
      toast.error(`Failed to delete brand: ${error.message}`);
    },
  });

  const handleCardClick = (brand: Brand) => {
    router.push(`/brands/${brand.id}`);
  };

  const handleDeleteClick = (brand: Brand) => {
    if (confirm(`Are you sure you want to delete ${brand.name}?`)) {
      deleteBrandMutation.mutate({ id: brand.id });
    }
  };

  if (isLoading) {
    return <div className="py-8 text-center">Loading brands...</div>;
  }

  if (error) {
    return <div className="py-8 text-center text-red-500">{error.message}</div>;
  }

  if (!brands || brands.length === 0) {
    return <div className="py-8 text-center">No brands found.</div>;
  }

  return (
    <div className="container mx-auto py-10">
      <h2 className="mb-6 text-2xl font-bold">Brands</h2>
      <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
        {brands.map((brand) => (
          <BrandCard
            key={brand.id}
            brand={brand}
            onCardClick={handleCardClick}
            onDeleteClick={handleDeleteClick}
          />
        ))}
      </div>
    </div>
  );
};
