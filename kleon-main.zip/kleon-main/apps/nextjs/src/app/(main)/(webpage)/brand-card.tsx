"use client";

import type { MouseEvent } from "react";

import { Button } from "@tonik/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@tonik/ui/card";
import { Trash } from "lucide-react";

export interface Brand {
  id: number;
  name: string;
  description?: string | null;
}

interface BrandCardProps {
  brand: Brand;
  onCardClick?: (brand: Brand) => void;
  onDeleteClick?: (brand: Brand) => void;
}

export const BrandCard = ({ brand, onCardClick, onDeleteClick }: BrandCardProps) => {
  const handleCardClick = () => {
    if (onCardClick) {
      onCardClick(brand);
    }
  };

  const handleDeleteClick = (e: MouseEvent<HTMLButtonElement>) => {
    // Prevent the card click event from firing when delete button is clicked
    e.stopPropagation();
    
    if (onDeleteClick) {
      onDeleteClick(brand);
    }
  };

  return (
    <Card 
      className="cursor-pointer hover:shadow-md transition-shadow"
      onClick={handleCardClick}
    >
      <CardHeader>
        <CardTitle>{brand.name}</CardTitle>
      </CardHeader>
      {brand.description && (
        <CardContent>
          <p className="text-gray-600">{brand.description}</p>
        </CardContent>
      )}
      <CardFooter className="flex justify-end">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleDeleteClick}
          className="flex items-center gap-1"
        >
          <Trash size={16} />
          <span>Delete</span>
        </Button>
      </CardFooter>
    </Card>
  );
};
