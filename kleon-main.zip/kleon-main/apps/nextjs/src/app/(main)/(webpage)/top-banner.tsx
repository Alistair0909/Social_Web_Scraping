import "server-only";

import { draftMode } from "next/headers";

import { AdminBar } from "@tonik/payload/components/admin-bar";

export const TopBanner = async () => {
  const { isEnabled } = await draftMode();

  const adminBarProps = {
    preview: isEnabled,
    adminPath: "/payload/admin",
    apiPath: "/payload/api",
  };

  return <AdminBar adminBarProps={adminBarProps} />;
};
