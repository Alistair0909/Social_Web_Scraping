import { draftMode } from "next/headers";
import Link from "next/link";
import { ArrowRight } from "lucide-react";

import { Button } from "@tonik/ui/button";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@tonik/ui/card";

import { api } from "~/trpc/rsc";
import { Pagination } from "./pagination";

export default async function Blog({
  searchParams,
}: {
  searchParams: Promise<{ page?: string }>;
}) {
  const currentPage = Number((await searchParams).page) || 1;
  const { isEnabled } = await draftMode();

  const posts = await api.blog.posts({
    page: currentPage,
    draft: isEnabled,
  });

  return (
    <div className="container px-4 py-12 md:px-6 md:py-24">
      <section className="mb-12">
        <h1 className="mb-4 text-4xl font-bold tracking-tighter sm:text-5xl">
          Blog Posts
        </h1>
        <p className="text-xl text-muted-foreground">
          Latest updates, guides and insights about Boring Stack
        </p>
      </section>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {posts.docs.map((post) => (
          <Card key={post.id} className="flex flex-col">
            <CardHeader>
              <CardTitle>{post.title}</CardTitle>
            </CardHeader>
            <CardContent className="flex-1">
              <p className="text-muted-foreground">{post.description}</p>
            </CardContent>
            <CardFooter>
              <Button variant="ghost" asChild>
                <Link href={`/blog/${post.slug}`} className="flex items-center">
                  Read More <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>

      <Pagination
        totalPages={Math.ceil(posts.totalPages)}
        currentPage={currentPage}
      />
    </div>
  );
}
