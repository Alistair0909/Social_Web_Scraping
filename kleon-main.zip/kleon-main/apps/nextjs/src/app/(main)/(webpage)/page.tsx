'use client';

import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { Button } from "@tonik/ui/button";
import { toast } from "@tonik/ui/toast";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@tonik/ui/form";
import { Input } from "@tonik/ui/input";
import { BrandsList } from "./brands-list";

import { api } from "~/trpc/react";

const formSchema = z.object({
  brandName: z.string().min(2, {
    message: "Brand name must be at least 2 characters.",
  }),
  description: z.string().min(2, {
    message: "Brand description must be at least 2 characters.",
  }),
});

const HomePage = () => {

  const createBrand = api.brand.create.useMutation({
    onSuccess: (data) => {
      toast.success(`Brand "${data?.name}" created successfully!`);
      form.reset();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      brandName: "",
      description: ""
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    createBrand.mutate(values);
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="mb-6 text-2xl font-bold">Create Brand</h1>

      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
          <FormField
            control={form.control}
            name="brandName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Brand Name</FormLabel>
                <FormControl>
                  <Input placeholder="Enter brand name" {...field} />
                </FormControl>
                <FormDescription>
                  Enter the name of the brand you want to create.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Brand description</FormLabel>
                <FormControl>
                  <Input placeholder="Please describe your brand here" {...field} />
                </FormControl>
                <FormDescription>
                  Provide a brief description of what your brand represents.
                </FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={createBrand.isPending}>
            {createBrand.isPending ? "Creating..." : "Create Brand"}
          </Button>
        </form>
      </Form>

      <BrandsList/>
    </div>
  );
};

export default HomePage;
