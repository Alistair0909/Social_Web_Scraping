import { draftMode } from "next/headers";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";

import { Media } from "@tonik/payload/components/media";
import { RichText } from "@tonik/payload/components/richtext";
import { Button } from "@tonik/ui/button";

import { api } from "~/trpc/rsc";

interface BlogPostPageProps {
  params: Promise<{
    slug: string;
  }>;
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
  const { isEnabled } = await draftMode();

  const post = await api.blog.post({
    slug: (await params).slug,
    draft: isEnabled,
  });

  if (!post) {
    notFound();
  }

  if (!post.content) {
    notFound();
  }

  return (
    <>
      <article className="container max-w-3xl px-4 py-12 md:px-6 md:py-24">
        <Button variant="ghost" asChild className="mb-8">
          <Link href="/blog" className="flex items-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Blog
          </Link>
        </Button>

        <header className="mb-12 grid gap-6">
          <Media resource={post.heroImage} />
          <h1 className="mb-4 text-4xl font-bold tracking-tighter sm:text-5xl">
            {post.title}
          </h1>
        </header>

        <div className="prose prose-gray max-w-none dark:prose-invert">
          <RichText data={post.content} />
        </div>
      </article>
    </>
  );
}
