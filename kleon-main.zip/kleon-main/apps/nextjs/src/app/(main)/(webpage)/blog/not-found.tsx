import Link from "next/link";
import { ArrowLeft } from "lucide-react";

import { Button } from "@tonik/ui/button";

export default function NotFound() {
  return (
    <div className="container flex min-h-[calc(100vh-4rem)] flex-col items-center justify-center px-4 md:px-6">
      <h2 className="mb-4 text-2xl font-bold">Post Not Found</h2>
      <p className="mb-8 text-muted-foreground">
        Sorry, we couldn't find the blog post you're looking for.
      </p>
      <Button asChild>
        <Link href="/blog" className="flex items-center">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Blog
        </Link>
      </Button>
    </div>
  );
}
