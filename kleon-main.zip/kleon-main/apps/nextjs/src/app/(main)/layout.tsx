import type { Metadata, Viewport } from "next";
import { GeistMono } from "geist/font/mono";
import { GeistSans } from "geist/font/sans";

import { env } from "@tonik/env";
import { cn } from "@tonik/ui";
import { ThemeProvider } from "@tonik/ui/theme";
import { Toaster } from "@tonik/ui/toast";

import { TRPCReactProvider } from "~/trpc/react";

import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(
    env.VERCEL_ENV === "production"
      ? "https://boring.tonik.com"
      : "http://localhost:3000",
  ),
  title: "Kleon",
  description: "The brand analyst",
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "white" },
    { media: "(prefers-color-scheme: dark)", color: "black" },
  ],
};

const Layout = ({ children }: { children: React.ReactNode }) => (
  <html lang="en" suppressHydrationWarning>
    <body
      className={cn(
        "min-h-screen bg-background font-sans text-foreground antialiased",
        GeistSans.variable,
        GeistMono.variable,
      )}
      suppressHydrationWarning
    >
      <ThemeProvider attribute="class" defaultTheme="system" enableSystem>
        <TRPCReactProvider>{children}</TRPCReactProvider>
        <Toaster />
      </ThemeProvider>
    </body>
  </html>
);

export default Layout;
