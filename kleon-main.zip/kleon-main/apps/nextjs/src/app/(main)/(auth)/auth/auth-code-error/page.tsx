const AuthErrorPage = () => {
  return <div>Auth code error</div>;
};

export default AuthErrorPage;
