import { defineNitroConfig } from 'nitropack/config';

export default defineNitroConfig({
  srcDir: 'src',

  // Info
  logLevel: 3,

  runtimeConfig: {
    apiSecret: process.env.API_SECRET || 'default_secret',
  },

  compatibilityDate: '2025-04-03',
  plugins: ["./plugins/queue.ts"],
  typescript: {
    strict: true
  }
});
