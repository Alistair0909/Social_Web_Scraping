import { logger } from '../utils/logger';

export default defineEventHandler((event) => {
  const start = Date.now();
  const { method, url } = event.node.req;
  
  logger.info(`Request: ${method} ${url}`);
  
  event.node.res.on('finish', () => {
    const duration = Date.now() - start;
    const { statusCode } = event.node.res;
    
    logger.info(`Response: ${method} ${url} ${statusCode} - ${duration}ms`);
  });
});

