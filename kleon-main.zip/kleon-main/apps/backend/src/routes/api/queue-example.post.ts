import { defineEventHandler, readBody } from 'h3';
import { sendToQueue } from '../../queue/send';

export default defineEventHandler(async (event) => {
  const body = await readBody(event);
  
  // Send a message to the queue
  const messageId = await sendToQueue('example-queue', {
    data: body,
    timestamp: new Date().toISOString(),
  });
  
  return {
    success: true,
    messageId,
  };
});


