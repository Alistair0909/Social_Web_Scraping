import { logger } from './utils/logger';

logger.info('Starting backend server...');

