import { defineNitroPlugin } from "nitropack/runtime/plugin";
import { createQueueWorker } from '../queue/worker';
import { logger } from "../utils/logger";

export default defineNitroPlugin((nitro) => {
  logger.info("Initializing queue worker...");

  const worker = createQueueWorker()

  logger.info("Starting queue worker...");

  void worker.start();

  function shutdown() {
    worker.stop()
  }

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
  nitro.hooks.hook("close", shutdown);
});
