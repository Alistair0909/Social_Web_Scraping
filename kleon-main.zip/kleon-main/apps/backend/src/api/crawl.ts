import { env } from "@tonik/env";
import { createClient } from "@tonik/supabase/server"

export default defineEventHandler(() => {
  const supabase = createClient({ supabaseApiUrl: env.SUPABASE_URL, supabaseKey: env.SUPABASE_SERVICE_ROLE_KEY })
});

