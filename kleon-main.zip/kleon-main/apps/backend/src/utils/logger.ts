import { createLogger } from '@tonik/logger';

export const logger = createLogger({
  name: 'backend',
});

