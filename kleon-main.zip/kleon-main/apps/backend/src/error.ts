import { logger } from './utils/logger';

export default defineEventHandler((event) => {
  event.node.res.on('error', (error) => {
    logger.error('Server error:', error);
  });
});

