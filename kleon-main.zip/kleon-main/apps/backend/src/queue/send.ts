import { createClient } from '@tonik/supabase/server';
import { logger } from '../utils/logger';
import { env } from '@tonik/env';
import { Json } from '@tonik/supabase/types';

const supabase = createClient({
  supabaseApiUrl: env.SUPABASE_URL,
  supabaseKey: env.SUPABASE_SERVICE_ROLE_KEY,
});

/**
 * Send a message to a Supabase PGMQ queue
 */
export async function sendToQueue<T extends Json>(queueName: string, message: T, options?: { delay?: number }) {
  try {
    const { data, error } = await supabase.schema('pgmq_public').rpc('send', {
      queue_name: queueName,
      message,
      sleep_seconds: options?.delay,
    });

    if (error) {
      logger.error(`Error sending message to queue ${queueName}`, { error });
      throw error;
    }

    logger.debug(`Sent message to queue ${queueName}`, {
      messageId: data[0],
    });

    return data[0];
  } catch (error) {
    logger.error(`Error sending message to queue ${queueName}`, { error });
    throw error;
  }
}

