import type { Json } from "@tonik/supabase/types";
import { SupabaseClient } from "@tonik/supabase";

import { logger } from "../utils/logger";

interface QueueMessage {
  id: number;
  message: unknown;
  vt: number | null;
}

type QueueHandler<T = unknown> = (
  message: T,
  processor: QueueProcessor,
) => Promise<void>;

export class QueueProcessor {
  private handlers = new Map<string, QueueHandler>();
  private isRunning = false;
  private pollInterval = 1000; // 1 second by default

  constructor(
    private supabase: SupabaseClient,
    options?: { pollInterval?: number },
  ) {
    if (options?.pollInterval) {
      this.pollInterval = options.pollInterval;
    }
  }

  /**
   * Register a handler for a specific queue
   */
  registerHandler<T = unknown>(queueName: string, handler: QueueHandler<T>) {
    this.handlers.set(queueName, handler as QueueHandler);
    logger.info(`Registered handler for queue: ${queueName}`);
    return this;
  }

  /**
   * Start processing queues
   */
  async start() {
    if (this.isRunning) {
      logger.warn("Queue processor is already running");
      return;
    }

    this.isRunning = true;
    logger.info("Starting queue processor");

    while (this.isRunning) {
      try {
        await this.processQueues();
      } catch (error) {
        logger.error(error, "Error processing queues");
      }

      // Wait before next poll
      await new Promise((resolve) => setTimeout(resolve, this.pollInterval));
    }
  }

  /**
   * Stop processing queues
   */
  stop() {
    logger.info("Stopping queue processor");
    this.isRunning = false;
  }

  /**
   * Process all registered queues
   */
  private async processQueues() {
    const queueNames = Array.from(this.handlers.keys());

    for (const queueName of queueNames) {
      await this.processQueue(queueName);
    }
  }

  /**
   * Process a single queue
   */
  private async processQueue(queueName: string) {
    const handler = this.handlers.get(queueName);
    if (!handler) {
      logger.warn(`No handler registered for queue: ${queueName}`);
      return;
    }

    try {
      // Read a message from the queue
      const { data, error } = await this.supabase
        .schema("pgmq_public")
        .rpc("pop", {
          queue_name: queueName,
        });

      if (error) {
        logger.error(error, `Error reading from queue ${queueName}`);
        return;
      }

      // If no messages, return
      if (!data || data.length === 0) {
        return;
      }

      const message = data[0] as QueueMessage;
      logger.debug(
        {
          messageId: message.id,
        },
        `Processing message from queue ${queueName}`,
      );

      // Process the message
      try {
        await handler(message.message, this);

        // Archive the message after successful processing
        await this.supabase.schema("pgmq_public").rpc("archive", {
          queue_name: queueName,
          message_id: message.id,
        });

        logger.debug(
          {
            messageId: message.id,
          },
          `Successfully processed message from queue ${queueName}`,
        );
      } catch (error) {
        logger.error(
          {
            messageId: message.id,
            error,
          },
          `Error processing message from queue ${queueName}`,
        );

        // Delete the message to return it to the queue
        await this.supabase.schema("pgmq_public").rpc("send", {
          queue_name: queueName,
          message: message.message as Json,
        });
      }
    } catch (error) {
      logger.error(error, `Error processing queue ${queueName}`);
    }
  }

  /**
   * Send a message to a queue
   */
  async sendMessage<T extends Json>(
    queueName: string,
    message: T,
    options?: { delay?: number },
  ) {
    try {
      const { data, error } = await this.supabase
        .schema("pgmq_public")
        .rpc("send", {
          queue_name: queueName,
          message,
          sleep_seconds: options?.delay,
        });

      if (error) {
        logger.error(error, `Error sending message to queue ${queueName}`);
        throw error;
      }

      logger.debug(
        {
          messageId: data[0],
        },
        `Sent message to queue ${queueName}`,
      );

      return data[0];
    } catch (error) {
      logger.error(error, `Error sending message to queue ${queueName}`);
      throw error;
    }
  }
}
