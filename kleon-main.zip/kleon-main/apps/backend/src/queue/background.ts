import { logger } from "../utils/logger";
import { createQueueWorker } from "./worker";

logger.info("Initializing queue worker...");

const worker = createQueueWorker();

logger.info("Starting queue worker...");

void worker.start();
