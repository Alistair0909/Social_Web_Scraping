/* eslint-disable @typescript-eslint/no-unsafe-member-access */
/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-unsafe-call */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */

import { smartScraper } from "scrapegraph-js";
import { z } from "zod";

import type { SupabaseClient } from "@tonik/supabase";
import { env } from "@tonik/env";
import { crawlRequestSchema } from "@tonik/models";
import { createClient } from "@tonik/supabase/server";

import { logger } from "../utils/logger";
import { QueueProcessor } from "./processor";

/**
 * Create and start a queue processor instance
 */
export function createQueueWorker() {
  const supabase = createClient({
    supabaseApiUrl: env.SUPABASE_URL,
    supabaseKey: env.SUPABASE_SERVICE_ROLE_KEY,
  });
  const processor = new QueueProcessor(supabase);

  // Register handlers for different queues
  processor.registerHandler("crawler_requests", async (message, processor) => {
    logger.info({ message }, "Processing message from crawler_requests");
    // Process the message here
    // For example, you could call an API, update a database, etc.
    const parsedMessage = crawlRequestSchema.parse(message);

    await scrapeProfilesInformation(supabase, parsedMessage.profileId);
  });

  // Start processing
  processor.start().catch((error) => {
    logger.error("Failed to start queue worker", { error });
    process.exit(1);
  });

  // Handle graceful shutdown
  const shutdown = () => {
    logger.info("Shutting down queue worker");
    processor.stop();
    process.exit(0);
  };

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);

  return processor;
}

async function scrapeProfilesInformation(
  supabase: SupabaseClient,
  profileId: number,
) {
  const { data: socialProfiles, error: socialProfilesErrors } = await supabase
    .from("social_profiles")
    .select("id, social_url, should_scrape, platform")
    .eq("should_scrape", true)
    .eq("id", profileId);

  if (socialProfilesErrors) {
    logger.error(socialProfilesErrors, "Error fetching social profiles");
    return;
  }

  for (const socialProfile of socialProfiles) {
    if (socialProfile.should_scrape && socialProfile.social_url) {
      logger.info(
        { socialProfileId: socialProfile.id },
        "Updating social profile before scraping",
      );

      const { error: updateSocialProfileError } = await supabase
        .from("social_profiles")
        .update({
          should_scrape: false,
          last_scraped_at: new Date().toISOString(),
        })
        .eq("id", socialProfile.id);

      if (updateSocialProfileError) {
        logger.error(updateSocialProfileError, "Error updating social profile");
        return;
      }

      switch (socialProfile.platform) {
        case "instagram": {
          const response = await scrapeInstagramProfile(
            socialProfile.social_url,
          );
          if (!response) {
            logger.error(
              { socialProfile },
              "No response from scrapeInstagramProfile",
            );
            break;
          }

          if(response.error && response.error.length > 0) {
            logger.error(
              { error: response.error, socialProfile },
              "Error scraping instagram profile",
            );
            break;
          }

          const result = response.result;

          logger.info(
            { url: response.website_url, scrapeRequestId: response.request_id },
            `Got data for ${response.website_url}`,
          );

          if (result) {
            const { error: updateInstagramProfileError } = await supabase
              .from("social_profiles")
              .update({
                should_scrape: false,
                last_scraped_at: new Date().toISOString(),
                followers: result.followers,
                name: result.profileName,
                social_handle: result.profileHandle,
                updated_at: new Date().toISOString(),
              })
              .eq("id", socialProfile.id);

            if (updateInstagramProfileError) {
              logger.error(
                updateInstagramProfileError,
                "Error updating instagram profile",
              );
            }

            await supabase.from("social_posts").upsert(
              await Promise.all(
                result.posts.map(async (p) => ({
                  url: p.url,
                  content_text: p.contentText,
                  metadata: { media_urls: p.mediaAssets, tags: p.tags },
                  sentiment: await getSentiment(p.contentText),
                })),
              ),
              {
                onConflict: "url",
                ignoreDuplicates: true,
              },
            );
          }
          break;
        }
        default: {
          logger.warn(
            { platform: socialProfile, profileId: socialProfile.id },
            "Unknown platform, skipping",
          );
        }
      }
    }
  }
}

const mediaAsset = z.object({
  url: z.string().describe("The url of the post's media asset"),
  type: z.enum(["image", "video"]).describe("The type of the media asset"),
});

const tag = z.object({
  name: z.string().describe("The name of the tag"),
  url: z.string().describe("The url of the tag"),
});

const instagramRelatedProfile = z.object({
  profileName: z.string().describe("The instagram profile name"),
  profileHandle: z.string().describe("The instagram profile handle"),
  profileUrl: z.string().describe("The instagram profile url"),
});

const instagramPost = z.object({
  likes: z.number().describe("The number of likes"),
  commentsCount: z.number().describe("The number of comments"),
  url: z.string().describe("The url of the post"),
  contentText: z.string().describe("The text content of the post"),
  mediaAssets: z.array(mediaAsset).describe("The post's media assets"),
  tags: z.array(tag).describe("The post's tags"),
});

const instagramProfileInformationSchema = z.object({
  profileName: z.string().describe("The instagram profile name"),
  profileHandle: z.string().describe("The instagram profile handle"),
  followers: z.number().describe("The number of followers"),
  postCount: z.number().describe("The number of posts"),
  relatedProfiles: z
    .array(instagramRelatedProfile)
    .describe("The related instagram profiles"),
  posts: z.array(instagramPost).describe("The instagram posts"),
});

interface ScrapeResponse<TSchema> {
  request_id: string;
  status: string;
  website_url: string;
  user_prompt: string;
  result: TSchema;
  error: string | null;
}

async function scrapeInstagramProfile(url: string) {
  const result = (await smartScraper(
    env.SCRAPEGRAPH_API_KEY,
    url,
    "Extract the instagram profile information",
    instagramProfileInformationSchema,
  )) as
    | ScrapeResponse<z.infer<typeof instagramProfileInformationSchema>>
    | undefined
    | null;

  return result;
}

async function getSentiment(text: string) {
  // Placeholder for sentiment analysis logic
  // You can use a library like sentiment or any other NLP library to analyze the text
  return await Promise.resolve({
    positive: 0.5,
    negative: 0.5,
    neutral: 0.0,
  });
}
