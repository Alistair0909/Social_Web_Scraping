# @tonik/backend

A simple Nitro server application.

## Development

```bash
# Install dependencies
pnpm install

# Start development server
pnpm dev
```

## Production

```bash
# Build for production
pnpm build

# Start production server
pnpm start
```

## Docker

```bash
# Build Docker image
docker build -t tonik-backend -f apps/backend/Dockerfile .

# Run Docker container
docker run -p 3000:3000 tonik-backend
```

## API Endpoints

- `GET /api/health` - Health check endpoint

