declare module 'scrapegraph-js';
