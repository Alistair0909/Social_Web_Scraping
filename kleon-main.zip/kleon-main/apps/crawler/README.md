# Crawler

A simple web crawler application built with Python.

## Development

### Setup

1. Create a virtual environment:
   ```
   python -m venv venv
   ```

2. Activate the virtual environment:
   - On macOS/Linux:
     ```
     source venv/bin/activate
     ```
   - On Windows:
     ```
     venv\Scripts\activate
     ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Install the package in development mode:
   ```
   pip install -e .
   ```

### Running the crawler

```
python main.py https://example.com --max-pages 5 --output results.json
```

## Docker

### Building the Docker image

```
docker build -t crawler .
```

### Running the crawler in Docker

```
docker run --rm crawler https://example.com --max-pages 5
```

To save the output to a file on your host machine:

```
docker run --rm -v $(pwd)/results:/app/results crawler https://example.com --max-pages 5 --output /app/results/output.json
```
