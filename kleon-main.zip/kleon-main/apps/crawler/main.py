#!/usr/bin/env python3
"""
Main entry point for the crawler application.
"""

import argparse
import sys
from scrapegraphai.graphs import SmartScraperGraph
from scrapegraphai.utils import prettify_exec_info


def parse_args():
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(description="Web crawler")
    parser.add_argument("url", help="The URL to start crawling from")
    parser.add_argument(
        "--max-pages", type=int, default=10, help="Maximum number of pages to crawl"
    )
    parser.add_argument(
        "--output", type=str, help="Output file to save results (JSON format)"
    )
    return parser.parse_args()


def main():
    """Main entry point."""

    graph_config = {
        "llm": {
            "model": "ollama/gemma3:4b",
            "temperature": 1,
            "format": "json",  # Ollama needs the format to be specified explicitly
            "model_tokens": 128000,  #  depending on the model set context length
            "base_url": "http://localhost:11434",  # set ollama URL of the local host (YOU CAN CHANGE IT, if you have a different endpoint
        },
        "loader_kwargs": {
            "backend": "playwright",
            "browser_name": "chrome",
            "proxy": {
                "server": "broker",
                "criteria": {
                    "anonymous": True,
                    "secure": True,
                    "countryset": {"IT"},
                    "timeout": 10.0,
                    "max_shape": 3,
                },
            },
        },
    }

    # ************************************************
    # Create the SmartScraperGraph instance and run it
    # ************************************************

    smart_scraper_graph = SmartScraperGraph(
        prompt="List me all the projects with their description.",
        # also accepts a string with the already downloaded HTML code
        source="https://perinim.github.io/projects",
        config=graph_config,
    )

    result = smart_scraper_graph.run()
    print(result)


if __name__ == "__main__":
    sys.exit(main())
