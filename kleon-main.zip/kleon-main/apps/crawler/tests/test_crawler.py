import pytest
from unittest.mock import MagicMock, patch

from src.crawler.crawler import Crawler


@pytest.fixture
def mock_response():
    """Create a mock response with sample HTML content."""
    mock = MagicMock()
    mock.text = """
    <html>
        <body>
            <a href="https://example.com/page1">Page 1</a>
            <a href="https://example.com/page2">Page 2</a>
            <a href="/relative-page">Relative Page</a>
        </body>
    </html>
    """
    return mock


class TestCrawler:
    def test_init(self):
        """Test crawler initialization."""
        crawler = Crawler("https://example.com")
        assert crawler.base_url == "https://example.com"
        assert "User-Agent" in crawler.headers

    def test_parse_links(self):
        """Test parsing links from HTML content."""
        crawler = Crawler("https://example.com")
        html = """
        <html>
            <body>
                <a href="https://example.com/page1">Page 1</a>
                <a href="https://example.com/page2">Page 2</a>
                <a href="/relative-page">Relative Page</a>
            </body>
        </html>
        """
        links = crawler.parse_links(html)
        assert len(links) == 3
        assert "https://example.com/page1" in links
        assert "https://example.com/page2" in links
        assert "https://example.com/relative-page" in links

    @patch("requests.Session.get")
    def test_fetch_page(self, mock_get, mock_response):
        """Test fetching a page."""
        mock_get.return_value = mock_response
        crawler = Crawler("https://example.com")
        content = crawler.fetch_page("https://example.com")
        assert content == mock_response.text
        mock_get.assert_called_once_with("https://example.com")

    @patch("requests.Session.get")
    def test_crawl(self, mock_get, mock_response):
        """Test crawling multiple pages."""
        mock_get.return_value = mock_response
        crawler = Crawler("https://example.com")
        results = crawler.crawl(max_pages=2)
        assert len(results) == 2
        assert "https://example.com" in results
