import requests
from bs4 import BeautifulSoup
from typing import Dict, List, Optional, Union


class Crawler:
    """A simple web crawler that fetches and parses web pages."""

    def __init__(self, base_url: str, headers: Optional[Dict[str, str]] = None):
        """
        Initialize the crawler with a base URL and optional headers.

        Args:
            base_url: The base URL to start crawling from
            headers: Optional HTTP headers to use for requests
        """
        self.base_url = base_url
        self.headers = headers or {
            "User-Agent": "Mozilla/5.0 (compatible; TonikCrawler/0.1.0)"
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def fetch_page(self, url: str) -> Optional[str]:
        """
        Fetch a web page and return its content.

        Args:
            url: The URL to fetch

        Returns:
            The page content as a string, or None if the request failed
        """
        try:
            response = self.session.get(url)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            print(f"Error fetching {url}: {e}")
            return None

    def parse_links(self, html_content: str) -> List[str]:
        """
        Parse all links from an HTML page.

        Args:
            html_content: The HTML content to parse

        Returns:
            A list of URLs found in the page
        """
        soup = BeautifulSoup(html_content, "html.parser")
        links = []

        for link in soup.find_all("a", href=True):
            href = link["href"]
            if href.startswith("http"):
                links.append(href)
            elif href.startswith("/"):
                links.append(f"{self.base_url.rstrip('/')}{href}")

        return links

    def crawl(self, max_pages: int = 10) -> Dict[str, Union[str, List[str]]]:
        """
        Crawl the website starting from the base URL.

        Args:
            max_pages: Maximum number of pages to crawl

        Returns:
            A dictionary mapping URLs to their content and links
        """
        visited = {}
        to_visit = [self.base_url]
        count = 0

        while to_visit and count < max_pages:
            url = to_visit.pop(0)
            if url in visited:
                continue

            print(f"Crawling: {url}")
            content = self.fetch_page(url)
            if content:
                links = self.parse_links(content)
                visited[url] = {
                    "content": content,
                    "links": links,
                }
                to_visit.extend([link for link in links if link not in visited])
                count += 1

        return visited
