// FIXME: This kinda stinks...
/// <reference types="../../tooling/eslint/types.d.ts" />

import baseConfig from "@tonik/eslint-config/base";

export default [...baseConfig];
