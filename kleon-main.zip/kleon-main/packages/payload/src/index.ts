import { getPayload as __getPayload } from "payload";

import type { Config } from "./payload-types.gen";
import config from "./payload.config";

declare module "payload" {
  // eslint-disable-next-line @typescript-eslint/no-empty-object-type
  export interface GeneratedTypes extends Config {}
}

export const getPayload = () => {
  return __getPayload({ config });
};
