import path from "path";
import { fileURLToPath } from "url";
import type { Config as PayloadConfig } from "payload";
import { vercelPostgresAdapter as postgresAdapter } from "@payloadcms/db-vercel-postgres";
import { buildConfig } from "payload";
import sharp from "sharp";

import { env } from "@tonik/env";

import type { Config } from "./payload-types.gen";
import { Categories } from "./collections/categories";
import { Media } from "./collections/media";
import { Posts } from "./collections/posts/config";
import { Users } from "./collections/users";
import { defaultLexical } from "./fields/default-lexical";
import { plugins } from "./plugins";

declare module "payload" {
  // eslint-disable-next-line @typescript-eslint/no-empty-interface
  export interface GeneratedTypes extends Config {}
}

const filename = fileURLToPath(import.meta.url);
const dirname = path.dirname(filename);

export const config = {
  routes: {
    admin: "/payload/admin",
    api: "/payload/api",
  },
  admin: {
    user: Users.slug,
  },
  collections: [Users, Posts, Categories, Media],
  secret: env.PAYLOAD_SECRET,
  editor: defaultLexical,

  typescript: {
    declare: false,
    autoGenerate: true,
    outputFile: path.resolve(dirname, "payload-types.gen.ts"),
  },
  db: postgresAdapter({
    idType: "serial",
    schemaName: "payload",
    pool: {
      connectionString: env.POSTGRES_URL,
    },
  }),
  // Sharp is used to resize images, crop, set focal point, etc.
  // We'll probably be able to remove it after reaching Payload 3.0 stable.
  sharp,
  graphQL: {
    disable: true,
  },
  plugins,
  // You can extend payload UI here but these components won't have access
  // to trpc or inngest. If you want to use them, you should extend payload
  // UI in the payload.config.ts file in the nextjs package.
  //
  // components: []
} satisfies PayloadConfig;

export default buildConfig(config);
