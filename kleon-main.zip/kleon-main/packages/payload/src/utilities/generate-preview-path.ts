import type { CollectionSlug, PayloadRequest } from "payload";

import { env } from "@tonik/env";

const collectionPrefixMap: Partial<Record<CollectionSlug, string>> = {
  posts: "/blog",
};

interface Props {
  collection: keyof typeof collectionPrefixMap;
  slug: string;
  req: PayloadRequest;
}

export const generatePreviewPath = ({ collection, slug, req }: Props) => {
  const path = `${collectionPrefixMap[collection]}/${slug}`;

  const params = {
    slug,
    collection,
    path,
  };

  const encodedParams = new URLSearchParams();

  Object.entries(params).forEach(([key, value]) => {
    encodedParams.append(key, value);
  });

  const isProduction = env.VERCEL_ENV === "production";
  const protocol = isProduction ? "https:" : req.protocol;

  const url = `${protocol}//${req.host}/payload/api/draft?${encodedParams.toString()}`;

  return url;
};
