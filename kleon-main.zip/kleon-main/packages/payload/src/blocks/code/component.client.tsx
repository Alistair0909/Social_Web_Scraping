"use client";

import React, { useState } from "react";
import { CopyIcon } from "lucide-react";
import { Highlight, themes } from "prism-react-renderer";

import { Button } from "@tonik/ui/button";
import { toast } from "@tonik/ui/toast";

interface CodeProps {
  code: string;
  language?: string;
}

export const Code = ({ code, language = "" }: CodeProps) => {
  if (!code) return null;

  return (
    <Highlight code={code} language={language} theme={themes.vsDark}>
      {({ getLineProps, getTokenProps, tokens }) => (
        <pre className="overflow-x-auto rounded border border-border bg-black p-4 text-xs">
          {tokens.map((line, i) => (
            <div key={i} {...getLineProps({ className: "table-row", line })}>
              <span className="table-cell select-none text-right text-white/25">
                {i + 1}
              </span>
              <span className="table-cell pl-4">
                {line.map((token, key) => (
                  <span key={key} {...getTokenProps({ token })} />
                ))}
              </span>
            </div>
          ))}
          <CopyButton code={code} />
        </pre>
      )}
    </Highlight>
  );
};

export function CopyButton({ code }: { code: string }) {
  const [text, setText] = useState("Copy");

  function updateCopyStatus() {
    if (text === "Copy") {
      setText(() => "Copied!");
      setTimeout(() => {
        setText(() => "Copy");
      }, 1000);
    }
  }

  return (
    <div className="flex justify-end align-middle">
      <Button
        className="flex gap-2"
        variant="secondary"
        size="sm"
        onClick={async () => {
          // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
          if (!navigator.clipboard) {
            toast.error("Clipboard API not available. Please copy manually");
            return;
          }

          await navigator.clipboard.writeText(code);
          updateCopyStatus();
        }}
      >
        <CopyIcon className="size-3.5" />
        {text}
      </Button>
    </div>
  );
}
