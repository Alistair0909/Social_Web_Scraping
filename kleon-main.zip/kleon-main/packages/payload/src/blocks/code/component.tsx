import React from "react";

import { Code } from "./component.client";

export interface CodeBlockProps {
  code?: string;
  language?: string;
  blockType: "code";
}

type CodeBlockFullProps = {
  className?: string;
} & CodeBlockProps;

export const CodeBlock = ({
  className,
  code,
  language,
}: CodeBlockFullProps) => {
  return (
    <div className={[className, "not-prose"].filter(Boolean).join(" ")}>
      <Code code={code ?? ""} language={language} />
    </div>
  );
};
