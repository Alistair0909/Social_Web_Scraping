import type { StaticImageData } from "next/image";

import { cn } from "@tonik/ui";

import type { MediaBlock as MediaBlockProps } from "../../payload-types.gen";
import { Media } from "../../components/media";
import { RichText } from "../../components/richtext";

type Props = MediaBlockProps & {
  breakout?: boolean;
  captionClassName?: string;
  className?: string;
  enableGutter?: boolean;
  imgClassName?: string;
  staticImage?: StaticImageData;
  disableInnerContainer?: boolean;
};

export const MediaBlock = (props: Props) => {
  const {
    captionClassName,
    className,
    enableGutter = true,
    imgClassName,
    media,
    staticImage,
    disableInnerContainer,
  } = props;

  let caption;
  if (media && typeof media === "object") caption = media.caption;

  return (
    <figure
      className={cn(
        "",
        {
          container: enableGutter,
        },
        className,
      )}
    >
      <Media
        className={cn(
          "w-full rounded-[0.8rem] border border-border",
          imgClassName,
        )}
        resource={media}
        src={staticImage}
      />
      {caption && (
        <figcaption
          className={cn(
            "mt-3",
            {
              container: !disableInnerContainer,
            },
            captionClassName,
          )}
        >
          <RichText data={caption} enableGutter={false} />
        </figcaption>
      )}
    </figure>
  );
};
