"use client";

import type { PayloadAdminBarProps, PayloadMeUser } from "payload-admin-bar";
import React, { useState } from "react";
import { useRouter, useSelectedLayoutSegments } from "next/navigation";
import { PayloadAdminBar } from "payload-admin-bar";

import { getUrlWithProtocol } from "@tonik/env/helpers";
import { cn } from "@tonik/ui";

const baseClass = "admin-bar";

const collectionLabels = {
  posts: {
    plural: "Posts",
    singular: "Post",
  },
};

const Title: React.FC = () => <span>Dashboard</span>;

export const AdminBar: React.FC<{
  adminBarProps?: PayloadAdminBarProps;
}> = ({ adminBarProps }) => {
  const segments = useSelectedLayoutSegments();
  const [show, setShow] = useState(false);
  const segment = segments[1];
  const collection =
    segment && segment in collectionLabels
      ? (segment as keyof typeof collectionLabels)
      : "posts";
  const router = useRouter();

  const onAuthChange = React.useCallback((user: PayloadMeUser) => {
    setShow(Boolean(user?.id));
  }, []);

  return (
    <div
      className={cn(baseClass, "bg-muted py-2 text-foreground", {
        block: show,
        hidden: !show,
      })}
    >
      <div className="container">
        <PayloadAdminBar
          {...adminBarProps}
          unstyled={true}
          className="flex flex-col gap-3 py-2 text-sm text-foreground sm:flex-row"
          classNames={{
            controls: cn(
              "flex flex-1 flex-col justify-end gap-3 font-medium text-foreground sm:flex-row",
            ),
            logo: cn("text-foreground hover:underline"),
            user: cn("text-foreground hover:underline"),
            create: cn("w-auto text-start hover:underline"),
            preview: cn("w-auto text-start hover:underline"),
            logout: cn("w-auto text-start hover:underline"),
          }}
          cmsURL={getUrlWithProtocol()}
          collection={collection}
          collectionLabels={{
            plural: collectionLabels[collection].plural,
            singular: collectionLabels[collection].singular,
          }}
          logo={<Title />}
          onAuthChange={onAuthChange}
          onPreviewExit={async () => {
            await fetch("/payload/api/exit-draft").then(() => {
              router.push("/");
              router.refresh();
            });
          }}
          style={{
            backgroundColor: "transparent",
            padding: 0,
            position: "relative",
            zIndex: "unset",
          }}
        />
      </div>
    </div>
  );
};
