import type { ComponentType } from "react";
import React, { Fragment } from "react";

import type { Props } from "./media/types";
import { ImageMedia } from "./media/image";
import { VideoMedia } from "./media/video";

export const Media = (props: Props) => {
  const { className, htmlElement, resource } = props;

  const isVideo =
    typeof resource === "object" && resource?.mimeType?.includes("video");
  const Tag = (htmlElement as ComponentType | undefined) ?? Fragment;

  return (
    <Tag
      {...(htmlElement !== null
        ? {
            className,
          }
        : {})}
    >
      {isVideo ? <VideoMedia {...props} /> : <ImageMedia {...props} />}
    </Tag>
  );
};
