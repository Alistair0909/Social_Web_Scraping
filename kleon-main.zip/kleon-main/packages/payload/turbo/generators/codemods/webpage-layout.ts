import type { namedTypes as t } from "ast-types";
import { builders as b } from "ast-types";
import * as recast from "recast";

import { addImports } from "@tonik/generators";

export const addComponentsToWebpageLayout = (ast: t.File, prefix: string) => {
  addImports(
    ast,
    `
 import { LivePreviewListener } from "@${prefix}/payload/components/live-preview-listener";
 import { TopBanner } from "./top-banner";
 `,
  );

  recast.visit(ast, {
    visitJSXElement(path) {
      if (path.node.openingElement.name.type === "JSXIdentifier") {
        if (path.node.openingElement.name.name === "BasicPage") {
          if (!path.node.children) path.node.children = [];
          let isLivePreviewAdded = false as boolean;
          let isTopBannerAdded = false as boolean;

          recast.visit(path.node, {
            visitJSXElement(path) {
              if (path.node.openingElement.name.type === "JSXIdentifier") {
                const name = path.node.openingElement.name.name;

                if (name === "LivePreviewListener") isLivePreviewAdded = true;
                else if (name === "TopBanner") isTopBannerAdded = true;
              }

              if (isTopBannerAdded && isLivePreviewAdded) {
                return false;
              }

              this.traverse(path);
            },
          });

          if (!isLivePreviewAdded) {
            path.node.children.unshift(
              b.jsxElement(
                b.jsxOpeningElement(
                  b.jsxIdentifier("LivePreviewListener"),
                  [],
                  true,
                ),
                null,
                [],
              ),
            );
            isLivePreviewAdded = true;
          }

          if (!isTopBannerAdded) {
            path.node.children.unshift(
              b.jsxElement(
                b.jsxOpeningElement(b.jsxIdentifier("TopBanner"), [], true),
                null,
                [],
              ),
            );
            isTopBannerAdded = true;
          }

          // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
          if (isTopBannerAdded && isLivePreviewAdded) {
            return false;
          }
        }
      }

      this.traverse(path);
    },
  });
};
