import { builders as b, namedTypes as t } from "ast-types";
import * as recast from "recast";
import * as typescriptParser from "recast/parsers/babel-ts";

import { modifyCreatetRPCContextDeclarationBody } from "@tonik/generators";

export const extendTRPCContext = (fileAST: t.File, prefix: string) => {
  const modify = modifyCreatetRPCContextDeclarationBody((statement) => {
    if (t.ArrowFunctionExpression.check(statement)) {
      if (!t.BlockStatement.check(statement.body)) {
        throw new Error("Expected block statement in createTRPCContext");
      }

      const returnStatement =
        statement.body.body[statement.body.body.length - 1];
      if (!t.ReturnStatement.check(returnStatement)) {
        throw new Error("Expected last statement to be return statement");
      }

      if (!t.ObjectExpression.check(returnStatement.argument)) {
        throw new Error(
          "Unsupported return statement. Expected object expression",
        );
      }

      if (
        returnStatement.argument.properties.some(
          (p) =>
            t.ObjectProperty.check(p) &&
            t.Identifier.check(p.key) &&
            p.key.name === "payload",
        )
      ) {
        console.log(
          "User property already exists in return statement. Skipping",
        );
        return;
      }

      if (!statement.async) {
        statement.async = true;
      }

      statement.body.body.splice(statement.body.body.length - 1, 1);

      const payloadStatement = (
        recast.parse(
          `
  const payload = await import("@${prefix}/payload").then((m) => m.getPayload());

`,
          { parser: typescriptParser },
        ) as t.File
      ).program.body[0];

      if (!t.VariableDeclaration.check(payloadStatement)) {
        throw new Error("Expected user statement to be variable declaration");
      }

      statement.body.body.push(payloadStatement);

      returnStatement.argument.properties.push(
        b.objectProperty(b.identifier("payload"), b.identifier("payload")),
      );

      statement.body.body.push(returnStatement);
    } else {
      throw new Error("Expected createTRPCContext to be an arrow function");
    }
  });

  for (const statement of fileAST.program.body) {
    modify(statement);
  }

  return fileAST;
};
