import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import type { PlopTypes } from "@turbo/gen";
import { builders as b, namedTypes as t } from "ast-types";
import yaml from "js-yaml";
import * as recast from "recast";
import * as typescriptParser from "recast/parsers/babel-ts";
import { z } from "zod";

import {
  addImports,
  appendTailwindPlugin,
  ensureCleanWorktree,
  extendRootRouter,
  parsePackageJson,
  renameDependencies,
} from "@tonik/generators";

import rootPackageJson from "../../../../package.json";
import workspacePackgeJson from "../../package.json";
import { extendTRPCContext } from "./codemods/api";
import { addComponentsToWebpageLayout } from "./codemods/webpage-layout";

export default function generator(plop: PlopTypes.NodePlopAPI): void {
  const monorepoRoot = path.resolve(plop.getDestBasePath(), "../..");
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
  const prefix = rootPackageJson.boring.namespace ?? "tonik";

  const promptsSchema = z.object({
    appPath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    apiPath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    supabasePath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    envPath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    tailwindPath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    e2ePath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),
  });

  plop.setGenerator("payload:enable", {
    description: "Enable payload feature",
    prompts: [
      {
        type: "input",
        name: "appPath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your Next.js app located?",
        default: "apps/nextjs",
      },
      {
        type: "input",
        name: "apiPath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your tRPC API package located?",
        default: "packages/api",
      },
      {
        type: "input",
        name: "supabasePath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your Supabase project located?",
        default: "supabase",
      },
      {
        type: "input",
        name: "envPath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your Env project located?",
        default: "packages/env",
      },
      {
        type: "input",
        name: "tailwindPath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your Tailwind tooling project located?",
        default: "tooling/tailwind",
      },
      {
        type: "input",
        name: "e2ePath" satisfies keyof typeof promptsSchema.shape,
        message: "Where are your E2E tests located?",
        default: "e2e",
      },
    ],
    actions: (untypedAnswers) => {
      ensureCleanWorktree();

      const answers = promptsSchema.parse(untypedAnswers);

      const generators: PlopTypes.ActionType[] = [];

      /**
       * Take payload dependencies in workspace package.json (@{{ namespace }}/payload)
       * and create payload3 catalog in pnpm-workspace.yaml
       */
      generators.push({
        type: "modify",
        path: path.join(monorepoRoot, "pnpm-workspace.yaml"),
        transform: (workspaceContent) => {
          const workspaceData = yaml.load(workspaceContent) as {
            packages: string[];
            catalogs?: Record<string, Record<string, string>>;
            catalog?: Record<string, string>;
          };

          function isPayloadPackage([pkg]: [string, string]): boolean {
            return pkg.startsWith("@payloadcms/") || pkg === "payload";
          }

          const payloadDependencies = Object.entries(
            workspacePackgeJson.dependencies,
          ).filter(isPayloadPackage);
          const payloadDevDependencies = Object.entries(
            workspacePackgeJson.devDependencies,
          ).filter(isPayloadPackage);
          const payloadPeerDependencies = Object.entries(
            workspacePackgeJson.devDependencies,
          ).filter(isPayloadPackage);

          const deps = new Map([
            ...payloadDependencies,
            ...payloadDevDependencies,
            ...payloadPeerDependencies,
          ]);

          if (!workspaceData.catalogs) {
            workspaceData.catalogs = {};
          }

          if (workspaceData.catalogs.payload3) {
            console.log(
              "pnpm-workspace.yaml already has payload3 catalog. Skipping",
            );
            return workspaceContent;
          }

          workspaceData.catalogs.payload3 = Object.fromEntries(
            [...deps.entries()].sort(),
          );

          return yaml.dump(workspaceData, { indent: 2 });
        },
      });

      generators.push({
        type: "modify",
        path: path.join(monorepoRoot, "package.json"),
        transform(content) {
          const pkg = parsePackageJson(content);

          const payloadScript = "pnpm --filter @tonik/nextjs payload";

          if (pkg.scripts?.payload) {
            if (pkg.scripts.payload === payloadScript) {
              return content;
            }

            console.warn(`!!! WARNING !!!`);
            console.warn(
              `Payload script exists in root package.json but does not match expected value`,
            );
            console.warn(`Expected: ${payloadScript}`);
            console.warn(`Found: ${pkg.scripts.payload}`);
            return content;
          }

          if (!pkg.scripts) pkg.scripts = {};

          pkg.scripts.payload = payloadScript;
          pkg.scripts["generate:importmap"] = "turbo generate:importmap";

          return JSON.stringify(pkg, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: "package.json",
        transform(content) {
          const pkg = parsePackageJson(content);

          pkg.name = pkg.name?.replace("@disabled/", `@${prefix}/`);
          pkg.dependencies = renameDependencies(pkg.dependencies, prefix);
          pkg.devDependencies = renameDependencies(pkg.devDependencies, prefix);
          pkg.peerDependencies = renameDependencies(
            pkg.peerDependencies,
            prefix,
          );

          // Helper function to check if package is a Payload package
          const isPayloadPackage = (pkgName: string): boolean => {
            return pkgName.startsWith("@payloadcms/") || pkgName === "payload";
          };

          // Update dependencies if they exist
          if (pkg.dependencies) {
            Object.keys(pkg.dependencies).forEach((dep) => {
              if (isPayloadPackage(dep) && pkg.dependencies) {
                pkg.dependencies[dep] = "catalog:payload3";
              }
            });
          }

          // Update devDependencies if they exist
          if (pkg.devDependencies) {
            Object.keys(pkg.devDependencies).forEach((dep) => {
              if (isPayloadPackage(dep) && pkg.devDependencies) {
                pkg.devDependencies[dep] = "catalog:payload3";
              }
            });
          }

          // Update peerDependencies if they exist
          if (typeof pkg.peerDependencies === "object") {
            Object.keys(pkg.peerDependencies).forEach((dep) => {
              if (isPayloadPackage(dep) && pkg.peerDependencies) {
                pkg.peerDependencies[dep] = "catalog:payload3";
              }
            });
          }

          return JSON.stringify(pkg, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.appPath, "package.json"),
        data: { namespace: prefix },
        transform(content) {
          const pkg = parsePackageJson(content);

          if (!pkg.dependencies) pkg.dependencies = {};

          pkg.dependencies[`@${prefix}/payload`] = "workspace:*";
          pkg.dependencies[`@payloadcms/next`] = "catalog:payload3";
          pkg.dependencies.payload = "catalog:payload3";

          if (!pkg.scripts) pkg.scripts = {};
          pkg.scripts.payload = "pnpm with-env payload --";

          return JSON.stringify(pkg, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.appPath, "tailwind.config.ts"),
        template: '"../../packages/payload/src/**/*.{ts,tsx}",',
        transform(content) {
          const ast = recast.parse(content, {
            parser: typescriptParser,
          }) as t.File;

          recast.visit(ast, {
            visitArrayExpression(path) {
              /* eslint-disable 
                @typescript-eslint/no-unnecessary-condition,
                @typescript-eslint/no-unsafe-member-access,
                @typescript-eslint/no-unsafe-assignment 
              */
              const maybeContentNode: unknown = path?.parentPath?.node;
              if (
                !(
                  t.ObjectProperty.check(maybeContentNode) &&
                  t.Identifier.check(maybeContentNode.key) &&
                  maybeContentNode.key.name === "content"
                )
              )
                return false;

              const pathToVerify = [
                t.ObjectExpression,
                t.ExportDefaultDeclaration,
              ];

              const parentToCheck = path?.parentPath?.parentPath;
              for (const verifier of pathToVerify) {
                if (!verifier.check(parentToCheck.node)) {
                  return false;
                }
              }

              path.node.elements.push(
                b.stringLiteral("../../packages/payload/src/**/*.{ts,tsx}"),
              );
            },
          });

          /* eslint-enable */

          return recast.print(ast).code;
        },
      });

      generators.push({
        type: "addMany",
        destination: answers.appPath,
        base: "templates/apps/nextjs",
        templateFiles: [
          "templates/apps/nextjs/**/*.jsx.hbs",
          "templates/apps/nextjs/**/*.js.hbs",
          "templates/apps/nextjs/**/*.ts.hbs",
          "templates/apps/nextjs/**/*.tsx.hbs",
        ],
        skipIfExists: true,
        data: { namespace: prefix },
      });

      generators.push(() => {
        /* eslint-disable @typescript-eslint/no-unsafe-assignment,@typescript-eslint/no-unsafe-member-access */
        const tsconfigPath = path.join(answers.appPath, "tsconfig.json");
        const tsconfig = JSON.parse(fs.readFileSync(tsconfigPath, "utf8"));

        if (!tsconfig.compilerOptions) {
          tsconfig.compilerOptions = {};
        }

        if (!tsconfig.compilerOptions.paths) {
          tsconfig.compilerOptions.paths = {};
        }

        if (!tsconfig.compilerOptions.paths["@payload-config"]) {
          tsconfig.compilerOptions.paths["@payload-config"] = [
            "./payload.config.ts",
          ];
          fs.writeFileSync(tsconfigPath, JSON.stringify(tsconfig, null, 2));
          return "Updated tsconfig.json with @payload-config path";
        }

        return "tsconfig.json already has @payload-config path";
        /* eslint-enable */
      });

      generators.push({
        type: "addMany",
        destination: answers.apiPath,
        base: "templates/packages/api",
        templateFiles: [
          "templates/packages/api/**/*.js.hbs",
          "templates/packages/api/**/*.jsx.hbs",
          "templates/packages/api/**/*.ts.hbs",
          "templates/packages/api/**/*.tsx.hbs",
        ],
        skipIfExists: true,
        data: { namespace: prefix },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.apiPath, "package.json"),
        data: { namespace: prefix },
        transform(content) {
          const pkg = parsePackageJson(content);

          if (!pkg.dependencies) pkg.dependencies = {};

          pkg.dependencies[`@${prefix}/payload`] = "workspace:*";

          return JSON.stringify(pkg, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.apiPath, "src", "root.ts"),
        data: { namespace: prefix },
        transform(content) {
          const ast = recast.parse(content, {
            parser: typescriptParser,
          }) as t.File;

          extendRootRouter(ast, [
            {
              routerKey: "blog",
              exportedRouterName: "blogRouter",
              routerImportPath: `./router/blog`,
            },
            {
              routerKey: "payload",
              exportedRouterName: "payloadRouter",
              routerImportPath: `./router/payload`,
            },
          ]);

          return recast.print(ast).code;
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.apiPath, "src", "trpc.ts"),
        data: { namespace: prefix },
        transform(content) {
          const ast = recast.parse(content, {
            parser: typescriptParser,
          }) as t.File;

          extendTRPCContext(ast, prefix);
          addImports(ast, `import { TRPCError } from "@trpc/server";`);

          return recast.print(ast).code;
        },
      });

      generators.push(() => {
        const template = fs.readFileSync(
          path.join(
            plop.getPlopfilePath(),
            "templates/packages/api/src/trpc.ts.append.hbs",
          ),
          { encoding: "utf-8" },
        );
        const renderedTemplate = plop.renderString(template, {
          noNamespace: prefix,
        });
        const targetPath = path.join(answers.apiPath, "src", "trpc.ts");
        const targetContent = fs.readFileSync(targetPath, {
          encoding: "utf-8",
        });
        if (targetContent.includes(renderedTemplate)) {
          return "trpc.ts already has the necessary exports (skipping)";
        }

        fs.writeFileSync(targetPath, targetContent + renderedTemplate);

        return "Added necessary exports to trpc.ts";
      });

      generators.push({
        type: "modify",
        path: path.join(answers.appPath, "src/app/(main)/(webpage)/layout.tsx"),
        transform(content) {
          const ast = recast.parse(content, {
            parser: typescriptParser,
          }) as t.File;

          addComponentsToWebpageLayout(ast, prefix);

          const finalCode = recast.print(ast).code;

          return finalCode;
        },
      });

      generators.push({
        type: "append",
        path: path.join(answers.envPath, "src/index.ts"),
        pattern: "server: {\n",
        unique: true,
        template:
          [
            "PAYLOAD_SECRET: z.string()",
            "PAYLOAD_MEDIA_S3_BUCKET: z.string()",
            "S3_ACCESS_KEY_ID: z.string()",
            "S3_SECRET_ACCESS_KEY: z.string()",
            "S3_REGION: z.string()",
            "S3_ENDPOINT: z.string()",
          ].join(",\n") + ",\n",
      });

      generators.push({
        type: "add",
        path: path.join(monorepoRoot, ".env"),
        skipIfExists: true,
        transform() {
          return fs.readFileSync(
            path.join(monorepoRoot, ".env.example"),
            "utf-8",
          );
        },
      });

      generators.push({
        type: "append",
        path: path.join(monorepoRoot, ".env.example"),
        unique: true,
        templateFile: "templates/.env.example.append.hbs",
      });

      generators.push({
        type: "append",
        path: path.join(monorepoRoot, ".env"),
        unique: true,
        templateFile: "templates/.env.append.hbs",
        abortOnFail: false,
      });

      generators.push({
        type: "modify",
        pattern: /.*turbo gen: remove line.*\n/g,
        template: "",
        path: "src/payload.config.ts",
      });

      generators.push({
        type: "modify",
        pattern: /.*turbo gen: remove line.*\n/g,
        template: "",
        path: "src/plugins.ts",
      });

      generators.push({
        type: "modify",
        pattern: /.*@typescript-eslint\/no-unsafe-assignment.*\n/g,
        template: "",
        path: "src/plugins.ts",
      });

      generators.push({
        type: "modify",
        path: path.join(answers.tailwindPath, "package.json"),
        transform(content) {
          const packageJson = parsePackageJson(content);

          packageJson.dependencies = {
            "@tailwindcss/typography": "^0.5.10",
            ...packageJson.dependencies,
          };

          return JSON.stringify(packageJson, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.tailwindPath, "web.ts"),
        transform(content) {
          const ast = recast.parse(content, {
            parser: typescriptParser,
          }) as t.File;

          addImports(ast, `import typography from "@tailwindcss/typography";`);

          appendTailwindPlugin(ast, b.identifier("typography"));

          return recast.print(ast).code;
        },
      });

      generators.push(() => {
        let response: Buffer | null = null;

        console.log("Installing dependencies...");

        try {
          response = execSync("pnpm dlx sherif@latest --fix", {
            cwd: monorepoRoot,
          });

          response = execSync("pnpm i", {
            cwd: monorepoRoot,
          });

          return "Dependencies installed";
        } catch (error) {
          if (response) console.error(response.toString());
          throw error;
        }
      });

      generators.push(() => {
        let response: Buffer | null = null;
        try {
          response = execSync("pnpm payload generate:importmap", {
            cwd: monorepoRoot,
            env: {
              ...process.env,
              SKIP_ENV_VALIDATION: "true",
            },
          });
          return "Generated import map";
        } catch (error) {
          if (response) console.error(response.toString());
          throw error;
        }
      });

      generators.push(() => {
        let response: Buffer | null = null;

        console.log("Formatting code...");

        try {
          response = execSync(
            `pnpm prettier --write ${answers.appPath}/** --list-different`,
            {
              cwd: monorepoRoot,
            },
          );

          response = execSync(
            `pnpm prettier --write ${monorepoRoot}/packages/payload/package.json --list-different`,
            {
              cwd: monorepoRoot,
            },
          );

          response = execSync(
            `pnpm prettier --write ${answers.apiPath}/** --list-different`,
            {
              cwd: monorepoRoot,
            },
          );

          response = execSync(
            `pnpm prettier --write ${answers.e2ePath}/** --list-different`,
            {
              cwd: monorepoRoot,
            },
          );

          return "Code formatted";
        } catch (error) {
          if (response) console.error(response.toString());
          throw error;
        }
      });

      return generators;
    },
  });
}
