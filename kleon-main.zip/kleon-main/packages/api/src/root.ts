import { authRouter } from "./router/auth";
import { blogRouter } from "./router/blog";
import { payloadRouter } from "./router/payload";
import { userRouter } from "./router/user";
import { brandRouter } from "./router/brand";
import { createTRPCRouter } from "./trpc";

export const appRouter = createTRPCRouter({
  auth: authRouter,
  user: userRouter,
  blog: blogRouter,
  payload: payloadRouter,
  brand: brandRouter
});

export type AppRouter = typeof appRouter;
