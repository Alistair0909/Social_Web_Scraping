import { z } from "zod";

import { createTRPCRouter, protectedProcedure } from "../trpc";

export const brandRouter = createTRPCRouter({
  create: protectedProcedure
    .input(z.object({ brandName: z.string() }))
    .mutation(async ({ ctx, input }) => {
      const response = await ctx.supabase
        .from("brands")
        .insert({
          name: input.brandName,
        })
        .select("name")
        .maybeSingle();

      if (response.error) {
        throw response.error;
      }

      return response.data;
    }),
  list: protectedProcedure.query(async ({ ctx }) => {
    const response = await ctx.supabase
      .from("brands")
      .select("id, name, description");
    if (response.error) {
      throw response.error;
    }

    return response.data
  }),

  delete: protectedProcedure
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const response = await ctx.supabase
        .from("brands")
        .delete()
        .eq("id", input.id);

      if (response.error) {
        throw response.error;
      }

      return response.data;
    }),

  getById: protectedProcedure
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const response = await ctx.supabase
        .from("brands")
        .select("id, name, description, website_url, logo_url, created_at, updated_at")
        .eq("id", input.id)
        .maybeSingle();

      if (response.error) {
        throw response.error;
      }

      return response.data;
    }),
});
