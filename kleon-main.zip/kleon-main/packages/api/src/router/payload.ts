import { z } from "zod";

import { createTRPCRouter, payloadProtectedProcedure } from "../trpc";

export const payloadRouter = createTRPCRouter({
  draft: payloadProtectedProcedure
    .input(
      z.object({
        collection: z.enum(["posts"]),
        slug: z.string(),
      }),
    )
    .query(async ({ ctx, input }) => {
      return await ctx.payload.find({
        collection: input.collection,
        draft: true,
        limit: 1,
        // pagination: false reduces overhead if you don't need totalDocs
        pagination: false,
        depth: 0,
        select: {},
        where: {
          slug: {
            equals: input.slug,
          },
        },
      });
    }),
});
