import { z } from "zod";

import { createTRPCRouter, publicProcedure } from "../trpc";

export const blogRouter = createTRPCRouter({
  posts: publicProcedure
    .input(z.object({ page: z.number(), draft: z.boolean().default(false) }))
    .query(async ({ ctx, input }) => {
      return await ctx.payload.find({
        collection: "posts",
        depth: 2,
        page: input.page,
        limit: 10,
        sort: "-title",
        where: {
          _status: {
            equals: input.draft ? "draft" : "published",
          },
        },
        draft: input.draft,
      });
    }),
  post: publicProcedure
    .input(z.object({ slug: z.string(), draft: z.boolean().default(false) }))
    .query(async ({ ctx, input }) => {
      const data = await ctx.payload.find({
        collection: "posts",
        page: 1,
        limit: 1,
        pagination: false,
        where: {
          and: [
            {
              _status: {
                equals: input.draft ? "draft" : "published",
              },
            },
            {
              slug: { equals: input.slug },
            },
          ],
        },
        draft: input.draft,
      });

      if (data.totalDocs === 0) {
        return null;
      }

      return data.docs[0] ?? null;
    }),
});
