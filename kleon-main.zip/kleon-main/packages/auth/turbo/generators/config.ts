import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import type { PlopTypes } from "@turbo/gen";
import { builders as b, namedTypes as t } from "ast-types";
import * as recast from "recast";
import * as typescriptParser from "recast/parsers/babel-ts";
import { z } from "zod";

import {
  ensureCleanWorktree,
  parsePackageJson,
  renameDependencies,
} from "@tonik/generators";

import rootPackageJson from "../../../../package.json";
import {
  appendProtectedProcedure,
  extendRootRouter,
  extendTRPCContext,
} from "./codemods/api";

export default function generator(plop: PlopTypes.NodePlopAPI): void {
  const monorepoRoot = path.resolve(plop.getDestBasePath(), "../..");
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
  const prefix = rootPackageJson.boring.namespace ?? "tonik";

  const promptsSchema = z.object({
    appPath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    apiPath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),

    e2ePath: z
      .string()
      .transform((p) =>
        !p.startsWith("/") ? path.resolve(monorepoRoot, p) : path.resolve(p),
      ),
  });

  plop.setGenerator("auth:enable", {
    description: "Enable auth feature",
    prompts: [
      {
        type: "input",
        name: "appPath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your Next.js app located?",
        default: "apps/nextjs",
      },
      {
        type: "input",
        name: "apiPath" satisfies keyof typeof promptsSchema.shape,
        message: "Where is your tRPC API package located?",
        default: "packages/api",
      },
      {
        type: "input",
        name: "e2ePath" satisfies keyof typeof promptsSchema.shape,
        message: "Where are your E2E tests located?",
        default: "e2e",
      },
    ],
    actions: (untypedAnswers) => {
      ensureCleanWorktree();

      const answers = promptsSchema.parse(untypedAnswers);

      const generators: PlopTypes.ActionType[] = [];

      generators.push({
        type: "modify",
        path: "package.json",
        data: { namespace: prefix },
        transform(content) {
          const pkg = parsePackageJson(content);

          pkg.name = pkg.name?.replace("@disabled/", `@${prefix}/`);
          pkg.dependencies = renameDependencies(pkg.dependencies, prefix);
          pkg.devDependencies = renameDependencies(pkg.devDependencies, prefix);
          pkg.peerDependencies = renameDependencies(
            pkg.peerDependencies,
            prefix,
          );

          return JSON.stringify(pkg, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.appPath, "package.json"),
        data: { namespace: prefix },
        transform(content) {
          const pkg = parsePackageJson(content);

          if (!pkg.dependencies) pkg.dependencies = {};
          pkg.dependencies[`@${prefix}/auth`] = "workspace:*";

          return JSON.stringify(pkg, null, 2);
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.apiPath, "package.json"),
        data: { namespace: prefix },
        transform(content) {
          const pkg = parsePackageJson(content);

          if (!pkg.dependencies) pkg.dependencies = {};
          pkg.dependencies[`@${prefix}/auth`] = "workspace:*";

          return JSON.stringify(pkg, null, 2);
        },
      });

      if (
        !fs.existsSync(
          path.join(
            answers.appPath,
            "src",
            "app",
            "(main)",
            "(auth)",
            "layout.tsx",
          ),
        )
      ) {
        generators.push({
          type: "addMany",
          destination: answers.apiPath,
          base: "templates/packages/api",
          templateFiles: "templates/packages/api/**",
          skipIfExists: false,
          force: true,
          data: { namespace: prefix },
        });

        generators.push({
          type: "addMany",
          destination: answers.appPath,
          base: "templates/apps/nextjs",
          templateFiles: "templates/apps/nextjs/**",
          skipIfExists: false,
          force: true,
          data: { namespace: prefix },
        });
      } else {
        console.log(
          "Auth pages already exist in Next.js. Found src/app/(main)/(auth)/layout.tsx file",
        );
      }

      generators.push({
        type: "modify",
        path: path.join(answers.appPath, "tailwind.config.ts"),
        template: '"../../packages/payload/src/**/*.{ts,tsx}",',
        transform(content) {
          const ast = recast.parse(content, {
            parser: typescriptParser,
          }) as t.File;

          recast.visit(ast, {
            visitArrayExpression(path) {
              /* eslint-disable 
                @typescript-eslint/no-unnecessary-condition,
                @typescript-eslint/no-unsafe-member-access,
                @typescript-eslint/no-unsafe-assignment 
              */
              const maybeContentNode: unknown = path?.parentPath?.node;
              if (
                !(
                  t.ObjectProperty.check(maybeContentNode) &&
                  t.Identifier.check(maybeContentNode.key) &&
                  maybeContentNode.key.name === "content"
                )
              )
                return false;

              const pathToVerify = [
                t.ObjectExpression,
                t.ExportDefaultDeclaration,
              ];

              const parentToCheck = path?.parentPath?.parentPath;
              for (const verifier of pathToVerify) {
                if (!verifier.check(parentToCheck.node)) {
                  return false;
                }
              }

              path.node.elements.push(
                b.stringLiteral("../../packages/auth/src/**/*.{ts,tsx}"),
              );
            },
          });

          /* eslint-enable */

          return recast.print(ast).code;
        },
      });

      // Extend tRPC context with session and user
      generators.push({
        type: "modify",
        path: path.join(answers.apiPath, "src/trpc.ts"),
        transform: (fileContent: string) => {
          const ast = recast.parse(fileContent, {
            parser: typescriptParser,
          }) as t.File;

          extendTRPCContext(ast);
          appendProtectedProcedure(ast);

          return recast.print(ast).code;
        },
      });

      generators.push({
        type: "modify",
        path: path.join(answers.apiPath, "src/root.ts"),
        transform: (fileContent: string) => {
          const ast = recast.parse(fileContent, {
            parser: typescriptParser,
          }) as t.File;

          extendRootRouter(ast);

          return recast.print(ast).code;
        },
      });

      generators.push({
        type: "add",
        path: path.join(answers.e2ePath, "fixtures", "logged-in.ts"),
        templateFile: "templates/e2e/fixtures/logged-in.ts.hbs",
        data: { namespace: prefix },
        skipIfExists: false,
        force: true,
      });

      generators.push({
        type: "append",
        path: path.join(answers.e2ePath, "pom", "webapp", "webapp-locators.ts"),
        pattern: "/** turbo gen: methods */",
        templateFile: "templates/e2e/pom/webapp/webapp-locators.ts.methods.hbs",
      });

      generators.push({
        type: "append",
        path: path.join(answers.e2ePath, "pom", "webapp", "webapp-page.ts"),
        pattern: "/** turbo gen: imports */",
        templateFile: "templates/e2e/pom/webapp/webapp-page.ts.imports.hbs",
      });

      generators.push({
        type: "append",
        path: path.join(answers.e2ePath, "pom", "webapp", "webapp-page.ts"),
        pattern: "/** turbo gen: methods */",
        templateFile: "templates/e2e/pom/webapp/webapp-page.ts.methods.hbs",
      });

      generators.push({
        type: "append",
        path: path.join(answers.e2ePath, "tests", "webapp", "homepage.spec.ts"),
        pattern: "/** turbo gen: imports */",
        templateFile: "templates/e2e/tests/webapp/homepage.spec.ts.imports.hbs",
      });

      generators.push({
        type: "append",
        path: path.join(answers.e2ePath, "tests", "webapp", "homepage.spec.ts"),
        templateFile: "templates/e2e/tests/webapp/homepage.spec.ts.append.hbs",
      });

      generators.push(() => {
        console.log("Installing dependencies");
        let response: Buffer | null = null;
        try {
          response = execSync("pnpm dlx sherif@latest --fix");

          response = execSync("pnpm i");

          console.log("Formatting code");

          response = execSync(
            `pnpm prettier --write ${answers.appPath}/** --list-different`,
          );

          response = execSync(
            `pnpm prettier --write ${monorepoRoot}/packages/auth/package.json --list-different`,
          );

          response = execSync(
            `pnpm prettier --write ${answers.apiPath}/** --list-different`,
          );

          response = execSync(
            `pnpm prettier --write ${answers.e2ePath}/** --list-different`,
          );

          return "Package scaffolded";
        } catch (error) {
          if (response) console.error(response.toString());
          throw error;
        }
      });
      return generators;
    },
  });
}
