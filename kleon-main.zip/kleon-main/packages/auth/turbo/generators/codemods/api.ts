import { builders as b, namedTypes as t } from "ast-types";
import * as recast from "recast";
import * as typescriptParser from "recast/parsers/babel-ts";

import { modifyCreatetRPCContextDeclarationBody } from "@tonik/generators";

export const extendTRPCContext = (fileAST: t.File) => {
  const modify = modifyCreatetRPCContextDeclarationBody((statement) => {
    if (t.ArrowFunctionExpression.check(statement)) {
      if (!t.BlockStatement.check(statement.body)) {
        throw new Error("Expected block statement in createTRPCContext");
      }

      if (
        !statement.body.body.some(
          (s) =>
            t.VariableDeclaration.check(s) &&
            s.declarations.some(
              (d) =>
                t.VariableDeclarator.check(d) &&
                t.Identifier.check(d.id) &&
                d.id.name === "supabaseAnonClient",
            ),
        )
      ) {
        throw new Error(
          "Expected supabaseAnonClient to be declared within createTRPCContext",
        );
      }

      const returnStatement =
        statement.body.body[statement.body.body.length - 1];
      if (!t.ReturnStatement.check(returnStatement)) {
        throw new Error("Expected last statement to be return statement");
      }

      if (!t.ObjectExpression.check(returnStatement.argument)) {
        throw new Error(
          "Unsupported return statement. Expected object expression",
        );
      }

      if (
        returnStatement.argument.properties.some(
          (p) =>
            t.ObjectProperty.check(p) &&
            t.Identifier.check(p.key) &&
            p.key.name === "user",
        )
      ) {
        console.log(
          "User property already exists in return statement. Skipping",
        );
        return;
      }

      if (
        returnStatement.argument.properties.some(
          (p) =>
            t.ObjectProperty.check(p) &&
            t.Identifier.check(p.key) &&
            p.key.name === "session",
        )
      ) {
        console.log(
          "Session property already exists in return statement. Skipping",
        );
        return;
      }

      if (!statement.async) {
        statement.async = true;
      }

      statement.body.body.splice(statement.body.body.length - 1, 1);

      const userStatement = (
        recast.parse(
          `
                    const {
                      data: { user },
                    } = await supabaseAnonClient.auth.getUser();

`,
          { parser: typescriptParser },
        ) as t.File
      ).program.body[0];

      if (!t.VariableDeclaration.check(userStatement)) {
        throw new Error("Expected user statement to be variable declaration");
      }

      statement.body.body.push(userStatement);

      const sessionStatement = (
        recast.parse(
          `
                    const {
                      data: { session },
                    } = await supabaseAnonClient.auth.getSession();

`,
          { parser: typescriptParser },
        ) as t.File
      ).program.body[0];

      if (!t.VariableDeclaration.check(sessionStatement)) {
        throw new Error(
          "Expected session statement to be variable declaration",
        );
      }

      statement.body.body.push(sessionStatement);

      returnStatement.argument.properties.push(
        b.objectProperty(b.identifier("user"), b.identifier("user")),
        b.objectProperty(b.identifier("session"), b.identifier("session")),
      );

      statement.body.body.push(returnStatement);
    } else {
      throw new Error("Expected createTRPCContext to be an arrow function");
    }
  });

  for (const statement of fileAST.program.body) {
    modify(statement);
  }

  return fileAST;
};

export const appendProtectedProcedure = (fileAST: t.File) => {
  if (
    fileAST.program.body.some(
      (s) =>
        t.ExportNamedDeclaration.check(s) &&
        t.VariableDeclaration.check(s.declaration) &&
        s.declaration.declarations.some(
          (d) =>
            t.VariableDeclarator.check(d) &&
            t.Identifier.check(d.id) &&
            d.id.name === "protectedProcedure",
        ),
    )
  ) {
    console.log("protectedProcedure already exists. Skipping");
    return fileAST;
  }

  if (
    !fileAST.program.body.some(
      (s) =>
        t.ImportDeclaration.check(s) &&
        s.specifiers &&
        t.ImportSpecifier.check(s.specifiers[0]) &&
        t.Identifier.check(s.specifiers[0].imported) &&
        s.specifiers[0].imported.name === "TRPCError",
    )
  ) {
    const existingTRPCImport = fileAST.program.body.find(
      (s) =>
        t.ImportDeclaration.check(s) &&
        s.importKind === "value" &&
        t.StringLiteral.check(s.source) &&
        s.source.value === "@trpc/server",
    );

    if (!existingTRPCImport) {
      const importStatement = b.importDeclaration(
        [
          b.importSpecifier(
            b.identifier("TRPCError"),
            b.identifier("TRPCError"),
          ),
        ],
        b.stringLiteral("trpc"),
      );

      fileAST.program.body.unshift(importStatement);
    } else {
      if (t.ImportDeclaration.check(existingTRPCImport)) {
        if (!existingTRPCImport.specifiers) existingTRPCImport.specifiers = [];
        existingTRPCImport.specifiers.push(
          b.importSpecifier(
            b.identifier("TRPCError"),
            b.identifier("TRPCError"),
          ),
        );
      }
    }
  } else {
    console.log("TRPCError already imported. Skipping");
  }

  const authProcedureStatements = (
    recast.parse(
      `

            /**
             * Protected (authenticated) procedure
             *
             * If you want a query or mutation to ONLY be accessible to logged in users, use this. It verifies
             * the session is valid and guarantees \`ctx.user\` is not null.
             *
             * @see https://trpc.io/docs/procedures
             */
            export const protectedProcedure = baseProcedure.use(({ ctx, next }) => {
              if (!ctx.user) {
                throw new TRPCError({ code: "UNAUTHORIZED" });
              }
            
              return next({
                ctx: {
                  user: ctx.user,
                },
              });
            });


`,
      { parser: typescriptParser },
    ) as t.File
  ).program.body;

  fileAST.program.body.push(...authProcedureStatements);
  return fileAST;
};

export const extendRootRouter = (fileAST: t.File) => {
  const imports = [
    ["authRouter", "./router/auth", "auth"],
    ["userRouter", "./router/user", "user"],
  ] as const;

  for (const [routerName, routerPath, propertyName] of imports) {
    if (
      fileAST.program.body.some(
        (s) =>
          t.ImportDeclaration.check(s) &&
          s.specifiers &&
          t.ImportSpecifier.check(s.specifiers[0]) &&
          t.Identifier.check(s.specifiers[0].imported) &&
          s.specifiers[0].imported.name === routerName,
      )
    ) {
      console.log(`${routerName} already imported. Skipping`);
    } else {
      const importStatement = b.importDeclaration(
        [b.importSpecifier(b.identifier(routerName), b.identifier(routerName))],
        b.stringLiteral(routerPath),
      );
      fileAST.program.body.unshift(importStatement);
    }

    const authProperty = b.objectProperty(
      b.identifier(propertyName),
      b.identifier(routerName),
    );

    for (const statement of fileAST.program.body) {
      if (t.ExportNamedDeclaration.check(statement)) {
        if (t.VariableDeclaration.check(statement.declaration)) {
          const declarator = statement.declaration.declarations.find(
            (d): d is t.VariableDeclarator =>
              t.VariableDeclarator.check(d) &&
              t.Identifier.check(d.id) &&
              d.id.name === "appRouter",
          );

          if (t.CallExpression.check(declarator?.init)) {
            const firstArg = declarator.init.arguments[0];
            if (t.ObjectExpression.check(firstArg)) {
              if (
                firstArg.properties.some(
                  (p) =>
                    t.ObjectProperty.check(p) &&
                    t.Identifier.check(p.key) &&
                    p.key.name === propertyName,
                )
              ) {
                console.log(
                  `"${propertyName}" property already exists. Skipping`,
                );
                break;
              }
              firstArg.properties.push(authProperty);
            } else {
              throw new Error(
                "Expected createTRPCRouter argument to be an object expression",
              );
            }
          } else {
            throw new Error("Expected appRouter to be declared");
          }
        }
      }
    }
  }
  return fileAST;
};
