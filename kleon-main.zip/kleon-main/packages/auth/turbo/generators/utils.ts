import fs from "fs";
import path from "path";

import { parsePackageJson } from "@tonik/generators";

export function loadPackageJson(dirPath: string) {
  const packageJsonPath = path.join(dirPath, "package.json");

  const stringContent = fs.readFileSync(packageJsonPath, {
    encoding: "utf-8",
  });

  return parsePackageJson(stringContent);
}

export const addDependency = (
  packageJson: string,
  dependencies: Record<string, string>,
  key: "dependencies" | "devDependencies",
) => {
  const pkg = parsePackageJson(packageJson);

  if (!pkg[key]) pkg[key] = {};

  for (const [name, version] of Object.entries(dependencies)) {
    pkg[key][name] = version;
  }

  return JSON.stringify(pkg, null, 2);
};

export function ensureDependency(
  packageJson: {
    dependencies?: Record<string, string>;
    devDependencies?: Record<string, string>;
  },
  dependencyKey: string,
) {
  if (packageJson.dependencies && dependencyKey in packageJson.dependencies)
    return;
  if (
    packageJson.devDependencies &&
    dependencyKey in packageJson.devDependencies
  )
    return;

  throw new Error(`"${dependencyKey}" dependency is missing in package.json`);
}
