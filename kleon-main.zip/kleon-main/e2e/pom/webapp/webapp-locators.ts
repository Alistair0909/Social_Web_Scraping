/** turbo gen: imports */

import type { Page } from "@playwright/test";

class WebAppLocators {
  public constructor(public page: Page) {}

  /** turbo gen: insert here */
}

export { WebAppLocators };
